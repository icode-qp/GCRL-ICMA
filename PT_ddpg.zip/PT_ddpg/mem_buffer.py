from collections import deque
import random
import numpy as np
import pickle

class MemoryBuffer:
    """
    # ---Memory Buffer---
    """

    def __init__(self, size):
        self.buffer = deque(maxlen=size)
        self.maxSize = size
        self.len = 0

        self.buffer_pm = deque(maxlen=size)
        self.len_pm = 0

    def sample(self, count):
        batch = []
        batch = random.sample(self.buffer, count)

        s_array = np.float32([array[0] for array in batch])
        a_array = np.float32([array[1] for array in batch])
        r_array = np.float32([array[2] for array in batch])
        new_s_array = np.float32([array[3] for array in batch])
        done_array = np.float32([array[4] for array in batch])
        ks_a_sample = np.float32([array[5] for array in batch])

        return s_array, a_array, r_array, new_s_array, done_array,ks_a_sample
    
    def sample_pm(self, count):
        batch = []
        batch = random.sample(self.buffer_pm, count)

        s_array = np.float32([array[0] for array in batch])
        a_array = np.float32([array[1] for array in batch])
        vp_array = np.float32([array[2] for array in batch])

        return s_array, a_array, vp_array

    def len(self):
        return len(self.buffer)
    
    def len_pm(self):
        return len(self.buffer_pm)

    def add(self, s, a, r, new_s, done,ks_a_sample):
        transition = (s, a, r, new_s, done,ks_a_sample)
        # self.len += 1
        # if self.len > self.maxSize:
        #     self.len = self.maxSize
        self.buffer.append(transition)

    def add_pm(self, s, a, vp):
        transition = (s, a, vp)
        # self.len += 1
        # if self.len > self.maxSize:
        #     self.len = self.maxSize
        self.buffer_pm.append(transition)

    def save(self, task_name, save_dir="buffers"):

        

        path=f"{save_dir}/save_buffer_{task_name}_buffer.pkl"

        with open(path, 'wb') as f:
            pickle.dump((self.buffer), f)
        print(f"[✔] Buffer saved to {path}")


