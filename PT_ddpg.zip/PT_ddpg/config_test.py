MIN_BUFFER_SIZE =1500#1500
MAX_BUFFER = 100000 

MAX_EPISODES = [100,100,100,100]
MAX_STEPS = [200,350,350,350]#350  #200STAGE1
# MAX_STEPS = [200,100,100,100]
TARGET_UPDATE_RATE = 200  #200
NETWORK_SAVE_RATE = 1000
LEARN_RATE = 20

STATE_DIMENSION = 94#94
ACTION_DIMENSION = 2 #2
ACTION_V_MAX = 0.2  # m/s
ACTION_W_MAX = 1.0  # rad/s
world = 'world_u'

BATCH_SIZE = 256#256
ACTOR_LR = 0.0001
CRITIC_LR = 0.0001
GAMMA = 0.99
TAU = 0.05
MODEL = 1
# STAGE = 21
fuzzy_lr=0.001

ALLOW_REVERSE = False
LOAD_PRETRAINED = True
GOAL_REACH_REWARD = 100.0
Collision=-10

MODEL_LOAD_PATH = "/home/robot/DDPG_AMR_Control/savemodels/stagec_kgzewcddpg_7"
MODEL_SAVE_PATH = "/home/robot/DDPG_AMR_Control/savemodels/stagec2_kgpt_1"

init_weight_v=[0.1]
init_weight_w=[0.9]
hybridnet_lr=0.0001

###############################################TD3


###############################################

if LOAD_PRETRAINED:
    # MODEL_LOAD_PATH = "savemodels/stagec_kgfcddpg_cs2"
    # MODEL_LOAD_PATH ="savemodels/stagec_kgdeewcsiddpg_cs1"
    # STEPS_TO_LOAD = [11000,51000,83000,155175]
    # STEPS_TO_LOAD = [11000,51000,83000,153368]
    # MODEL_LOAD_PATH="savemodels/stagec_kgfcddpg_cs"
    # MODEL_LOAD_PATH="savemodels/stagec_kgdesiewcddpg_nma_cs1" 
    MODEL_LOAD_PATH='/home/robot/DDPG_AMR_Control/savemodels/stagec2_kgpt_1'
    # STEPS_TO_LOAD = 6000

experiment_name="kgpt_test1"
model_list=[[12000,1],[78000,2],[134000,3],[180000,4]] #kgdesiewc "savemodels/stagec_kgdeewcsiddpg_cs1"


task=[
        ["turtlebot3_stage_dfc1",1],
        ["turtlebot3_stage_dfc2",2],
        ["turtlebot3_stage_dfc3",3],
        ["turtlebot3_stage_dfc4",4]]


task_init_index=0





