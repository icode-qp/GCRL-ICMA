#!/usr/bin/env python

import rospy
import os
import sys

from std_msgs.msg import Float32
import torch
import torch.nn.functional as F

# Local imports
import config
import torch.nn as nn
from models_big import Actor, Critic
import numpy as np
import random
import pdb
from itertools import islice 
# ---Functions to make network updates---#

def soft_update(target, source, tau):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(target_param.data * (1.0 - tau) + param.data * tau)

def fixed_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 如果你使用GPU
    torch.cuda.manual_seed_all(seed)  # 如果你有多个GPU
    torch.backends.cudnn.deterministic = True  # 设置为True以确保结果可重复
    torch.backends.cudnn.benchmark = False  # 设置为False以提高结果可重复性
    np.random.seed(seed)
    random.seed(seed)

def hard_update(target, source):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(param.data)

class hybrid_net(torch.nn.Module):
    def __init__(self,model_num,action_dim,action_v_max,action_w_max):
        super(hybrid_net, self).__init__()
        self.model_num=model_num
        self.action_w_max=action_w_max
        self.action_v_max=action_v_max

        self.theta1 = nn.Parameter(torch.tensor([[0.0]]))
        # self.theta2 = nn.Parameter(torch.tensor([[0.0]])).requires_grad = False  


    def forward(self,x):
        # self.hy_v_layer.weight.data.copy_(self.hy_w_layer.weight.data)
        
        action_v=x[:,0].unsqueeze(1)*self.theta1  +  x[:,2].unsqueeze(1)*(1-self.theta1)
        action_w=x[:,1].unsqueeze(1)*self.theta1 + x[:,3].unsqueeze(1)*(1-self.theta1)
        action = torch.cat((action_v,action_w),dim=1)

        return action

class DDPGAgent:

    def __init__(self, state_dim, action_dim, action_v_max, action_w_max, memory_buffer = None, path_save = "models", path_load = "models"):
        torch.set_default_tensor_type('torch.cuda.FloatTensor' if torch.cuda.is_available() else 'torch.FloatTensor')
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.action_v_max = action_v_max
        self.action_w_max = action_w_max
        self.memory_buffer = memory_buffer
        self.is_cuda_available = torch.cuda.is_available()
        self.device = torch.device("cuda" if self.is_cuda_available else "cpu")
        
        fixed_seed(config.randseed)

        self.actor = Actor(self.state_dim, self.action_dim, self.action_v_max, self.action_w_max).to(self.device)
        self.target_actor = Actor(self.state_dim, self.action_dim, self.action_v_max, self.action_w_max).to(self.device)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), config.ACTOR_LR)

        self.critic = Critic(self.state_dim, self.action_dim).to(self.device)
        self.p_critic = Critic(self.state_dim, self.action_dim).to(self.device)
        self.target_critic = Critic(self.state_dim, self.action_dim).to(self.device)

        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), config.CRITIC_LR)
        self.p_critic_optimizer = torch.optim.Adam(self.p_critic.parameters(), config.CRITIC_LR)
        

        self.path_save = path_save
        self.path_load = path_load
        self.critic_loss = -1
        self.actor_loss = -1

        hard_update(self.target_actor, self.actor)
        hard_update(self.target_critic, self.critic)


        self.ref_actor = Actor(self.state_dim, self.action_dim, self.action_v_max, self.action_w_max).to(self.device)
        self.ref_actor.load_state_dict(torch.load(f"{self.path_load}/save_agent_{config.steps}/actor.pt"))

        self.hybridnet=hybrid_net(2,2,self.action_v_max ,
                        self.action_w_max).to(self.device)
        
        self.target_hybridnet=hybrid_net(2,2,self.action_v_max ,
                        self.action_w_max).to(self.device)

        init_weight_v = torch.tensor([config.init_weight_v]).to(self.device)
        init_weight_w = torch.tensor([config.init_weight_w]).to(self.device)

        self.hybridnet.theta1=nn.Parameter(init_weight_v)
        # self.hybridnet.theta2=nn.Parameter(init_weight_w)

        hard_update(self.target_hybridnet, self.hybridnet)

        self.hybridnet_optimizer = torch.optim.Adam(
            self.hybridnet.parameters(), lr=config.hybridnet_lr)
        
        self.simlar_cof=self.hybridnet.theta1.detach()
        self.theta_t=config.theta_t
        self.clone_p=config.clone_p

    def get_action(self, state):
        
        state = torch.from_numpy(state).to(self.device)
        action = self.actor.forward(state).detach()
        with torch.no_grad():
            curr_T_vals = self.critic.forward(state.unsqueeze(0),action.unsqueeze(0)).squeeze(0)
            curr_P_vals = self.p_critic.forward(state.unsqueeze(0),action.unsqueeze(0)).squeeze(0)
            curr_Q_vals = curr_T_vals + curr_P_vals
        return action.data.cpu().numpy(),curr_Q_vals.data.cpu().numpy()
    
    def get_action_test(self, state):
        
        state = torch.from_numpy(state).to(self.device)
        action = self.actor.forward(state).detach()
        return action.data.cpu().numpy()

    def learn(self):
        s_sample, a_sample, r_sample, new_s_sample, done_sample,ks_a_sample= self.memory_buffer.sample(config.BATCH_SIZE)

        s_sample = torch.from_numpy(s_sample).to(self.device)
        a_sample = torch.from_numpy(a_sample).to(self.device)
        r_sample = torch.from_numpy(r_sample).to(self.device)
        new_s_sample = torch.from_numpy(new_s_sample).to(self.device)
        done_sample = torch.from_numpy(done_sample).to(self.device)
        ks_a_sample = torch.from_numpy(ks_a_sample).to(self.device)

        # -------------- optimize critic ------------------
        with torch.no_grad():

            target_actions = self.target_actor.forward(new_s_sample).detach()
            target_critic_values = torch.squeeze(self.target_critic.forward(new_s_sample, target_actions).detach())
            p_critic_values_next = torch.squeeze(self.p_critic.forward(new_s_sample,target_actions))

            p_critic_values = torch.squeeze(self.p_critic.forward(s_sample,a_sample))

        critic_value = torch.squeeze(self.critic.forward(s_sample, a_sample))

        
        target = r_sample + (1 - done_sample) * config.GAMMA * (p_critic_values_next+target_critic_values)

        critic_loss = F.smooth_l1_loss(critic_value+p_critic_values, target)
        
        self.critic_loss = critic_loss.data.cpu().numpy()
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 2)
        self.critic_optimizer.step()


        # ------------ optimize actor ------------------
        self.simlar_cof=self.hybridnet.theta1.detach()
        policy_actions = self.actor.forward(s_sample)
        actor_loss = -self.simlar_cof*torch.mean(self.critic.forward(s_sample, policy_actions)+self.p_critic(s_sample,policy_actions))\
            +(1-self.simlar_cof+self.theta_t)*self.clone_p*(F.mse_loss(policy_actions,ks_a_sample))
        self.actor_loss = actor_loss.data.cpu().numpy()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 2)
        self.actor_optimizer.step()

         # ------------ optimize hybrid ------------------
        hybrid_action=self.hybridnet(torch.cat((policy_actions.detach(), ks_a_sample), dim=1))
        
        hybrid_loss= -torch.mean(self.critic.forward(s_sample, hybrid_action)+self.p_critic(s_sample,hybrid_action))

        self.hybridnet_optimizer.zero_grad()

        hybrid_loss.backward()

        torch.nn.utils.clip_grad_norm_(self.hybridnet.parameters(), 0.5)

        self.hybridnet_optimizer.step()

        self.hybridnet.theta1.data.clamp_(0.0,  1.0)

    def hybrid_action_hynet(self,state): #用于与环境交互的动作

            action,vp=self.get_action(state)
            
            action= torch.tensor(action).unsqueeze(0)
            
            state = torch.from_numpy(state).to(self.device)

            k_action = self.ref_actor.forward(state).detach().unsqueeze(0)

            hybrid_action=self.hybridnet(torch.cat((action, k_action), dim=1)).detach().squeeze(0).cpu().numpy()

            self.ks_action_save=k_action.squeeze(0).cpu().numpy()
            self.u_action_save=action.squeeze(0).cpu().numpy()
            self.h_action_save=hybrid_action

            return self.h_action_save,vp
    
    def p_critic_learn(self):

        u_steps = (len(self.memory_buffer.buffer_pm)//config.BATCH_SIZE) - 1
        for p_update in range(u_steps):
            start = p_update * config.BATCH_SIZE
            end = start + config.BATCH_SIZE
            # batch=self.memory_buffer.buffer_pm[start:end]

            batch=list(islice(self.memory_buffer.buffer_pm,start,end))

            s_sample = np.float32([array[0] for array in batch])
            a_sample = np.float32([array[1] for array in batch])
            vp_sample = np.float32([array[2] for array in batch])

            s_sample = torch.from_numpy(s_sample).to(self.device)
            a_sample = torch.from_numpy(a_sample).to(self.device)
            vp_sample = torch.from_numpy(vp_sample).to(self.device)

            with torch.no_grad():
                critic_values = torch.squeeze(self.critic.forward(s_sample,a_sample))+torch.squeeze(vp_sample)

            p_critic_values= torch.squeeze(self.p_critic.forward(s_sample,a_sample))
            loss = F.smooth_l1_loss(p_critic_values,critic_values)
            self.p_critic_optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.p_critic.parameters(), 2)
            self.p_critic_optimizer.step()

    def qt_reset(self):
        self.critic = Critic(self.state_dim, self.action_dim).to(self.device)
        hard_update(self.target_critic, self.critic)
    # do something with s_array, a_array, vp_array



    def get_critic_loss(self):
        return self.critic_loss
        
    def get_actor_loss(self):
        return self.actor_loss
        
    def update_target(self):
        soft_update(self.target_actor, self.actor, config.TAU)
        soft_update(self.target_critic, self.critic, config.TAU)

    def save_models(self, steps):
        if not os.path.isdir(f"{self.path_save}/save_agent_{steps}"):
            os.makedirs(f"{self.path_save}/save_agent_{steps}")
        
        torch.save(self.target_actor.state_dict(), f"{self.path_save}/save_agent_{steps}/actor.pt")
        torch.save(self.p_critic.state_dict(), f"{self.path_save}/save_agent_{steps}/critic.pt")
        print('****Models saved***')

    def load_models(self, steps):
        self.actor.load_state_dict(torch.load(f"{self.path_load}/save_agent_{steps}/actor.pt"))
        self.critic.load_state_dict(torch.load(f"{self.path_load}/save_agent_{steps}/critic.pt"))
        hard_update(self.target_actor, self.actor)
        hard_update(self.p_critic, self.critic)
        print('***Models load***')


