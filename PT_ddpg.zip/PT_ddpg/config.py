MIN_BUFFER_SIZE =1500#1500
MAX_BUFFER = 100000 

MAX_EPISODES = [300,1000,1000,1000]
MAX_STEPS = [200,350,350,350]#350  #200STAGE1
TARGET_UPDATE_RATE = 200  #200
NETWORK_SAVE_RATE = 1000
LEARN_RATE = 20

STATE_DIMENSION = 94#94
ACTION_DIMENSION = 2 #2
ACTION_V_MAX = 0.2  # m/s
ACTION_W_MAX = 1.0  # rad/s
world = 'world_u'

BATCH_SIZE = 256 #256
ACTOR_LR = 0.0001
CRITIC_LR = 0.0001
GAMMA = 0.99
TAU = 0.05
MODEL = 1
# STAGE = 21


ALLOW_REVERSE = False
LOAD_PRETRAINED = False
GOAL_REACH_REWARD = 100.0
Collision=-10

MODEL_LOAD_PATH = "/home/robot/DDPG_AMR_Control/savemodels/stagec_kgdeewcsiddpg_cs1"
MODEL_SAVE_PATH = "/home/robot/DDPG_AMR_Control/savemodels/stagec2_kgpt_1"

# note="crlpaper2_ddpg_1"

init_weight_v=[0.1]
init_weight_w=[0.9]
hybridnet_lr=0.0001

###############################################TD3
policy_delay=1
policy_noise=0.1
policy_noise_clip=0.1

###############################################
experiment_name='KGPT_ddpg_1'
steps=150000
if LOAD_PRETRAINED:
    MODEL_LOAD_PATH = "/home/robot/DDPG_AMR_Control/savemodels/stagec_ewcddpg_1"
    STEPS_TO_LOAD = 142000


# task=[
#         ["turtlebot3_stage_1",1],
#         ["turtlebot3_stage_2gc3",3],
#         ["turtlebot3_stage_2gc4",4],
#         ["turtlebot3_stage_5",5]]


task=[
        ["turtlebot3_stage_dfc1",1],
        ["turtlebot3_stage_dfc2",2],
        ["turtlebot3_stage_dfc3",3],
        ["turtlebot3_stage_dfc4",4]]



task_init_index=0
theta_t=0.2
clone_p=100
randseed=0