import copy
import numpy as np
import rospy
from std_msgs.msg import Float32
import os
import sys
from environments_paper2 import Env
from mem_buffer import MemoryBuffer
from kgagents import DDPGAgent
import config_test
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from actionlib_msgs.msg  import GoalStatusArray 
from noises import OUNoise

#########这是第3篇最终训练

from colorama import Fore, Style
import wandb
import random  
import torch
import subprocess
import time
import signal
import pandas as pd
from torch import nn
import swanlab
gazebo_process = None
nav_process=None
def init_plotting():
    config_dict = {key: value for key, value in config_test.__dict__.items() if not key.startswith("__")}


    swanlab.init(
    # 设置项目名
    project="ICMA",
    experiment_name=config_test.experiment_name,
    # 设置超参数
    config = config_dict,
    )

def run_training(tasks):
    global pub_average_reward, pub_episode_reward
    print('State Dimensions: ' + str(config_test.STATE_DIMENSION))
    print('Action Dimensions: ' + str(config_test.ACTION_DIMENSION))
    print('Action Max: ' + str(config_test.ACTION_V_MAX) + ' m/s and ' + str(config_test.ACTION_W_MAX) + ' rad/s')
    
    memory_buffer = MemoryBuffer(config_test.MAX_BUFFER)
    
    agent = DDPGAgent(config_test.STATE_DIMENSION, 
                        config_test.ACTION_DIMENSION, 
                        config_test.ACTION_V_MAX,
                        config_test.ACTION_W_MAX, 
                        memory_buffer,
                        path_save=config_test.MODEL_SAVE_PATH,
                        path_load = config_test.MODEL_LOAD_PATH)
    
    
    steps = 0
    ep1=0
    


    for model_n,i in config_test.model_list:

        if config_test.LOAD_PRETRAINED:
            agent.load_models(model_n)
            
            print(f"--------------- Loaded Model {model_n} ------------------")

        task_index=config_test.task_init_index
        j=0

        for task,task_id in tasks:
        # for task,task_id in tasks[j:]:
            
            task_steps=0
            print(f"---------------------- STARTING TASK {task_id} --------------------")
            
            launch_environment1(task)
            env = Env(action_dim = config_test.ACTION_DIMENSION)
            env.respawn_goal.stage=task_id
            rewards_all_episodes = []
            gaol_reach_all_episodes =[]

            

            for ep in range(config_test.MAX_EPISODES[task_index]):
                print(f"---------------------- EPISODE {ep + 1} --------------------")
                done = False

                # nav_start(nav_name)

                state = env.reset()
                
                rewards_current_episode = 0.0
                past_action = np.zeros(config_test.ACTION_DIMENSION)
                episode_steps = 0
                ep1=ep1+1
                agent.theta_ref=state[92]
                
                while not done:
                    steps += 1
                    task_steps+=1
                    episode_steps += 1
                    state = np.float32(state)

                    action = agent.get_action_test(state)

                    next_state, reward, done = env.step(action, past_action)

                    
                    rewards_current_episode += reward

                    next_state = np.float32(next_state)


                    state = copy.deepcopy(next_state)
                    
                    
                    past_action = copy.deepcopy(action)

                    if config_test.MAX_STEPS[task_index] <= episode_steps:
                        done = True
                    
                        
                rewards_all_episodes.append(rewards_current_episode)
                gaol_reach_all_episodes.append(env.reach_score)
                        
                avg_reward = np.mean(rewards_all_episodes[max(0, ep - 100):(ep + 1)])
                avg_reach_rate = np.mean(gaol_reach_all_episodes[max(0, ep - 100):(ep + 1)])
                
                swanlab.log({"episodes": ep1,
                        "episode_reward": rewards_current_episode,
                        "average_reward": avg_reward,
                        "avg_reach_rate": avg_reach_rate,
                        })
                
                swanlab.log({"collution_num":env.collision_num,
                            "goal_rech_num":env.goal_reach_num})
                
                # terminate_nav()
                print("------------------------------------- EPISODE END -----------------------------------------".format(ep + 1))
            
            j=j+1

            task_index=task_index+1





def launch_environment(env_name,nav_launch_name):
    global gazebo_process ,nav_process
    try:
        # 清理上一个环境
        terminate_gazebo()

        print(f"Launching environment: {env_name}")
        
        # 确保环境变量正确传递
        env = os.environ.copy()
        env['DISPLAY'] = os.getenv('DISPLAY', ':0')
        
        # 启动新的 Gazebo 环境
        gazebo_process = subprocess.Popen(
            ['roslaunch', 'turtlebot3_gazebo', f'{env_name}.launch'],
            env=env,
            preexec_fn=os.setsid,
            stdout=None,
            stderr=None
        )
        
        # 等待环境启动
        time.sleep(10)

          # 根据命名规范生成导航文件名
        print(f"Starting navigation: {nav_launch_name}")
        
        # nav_process = subprocess.Popen(
        #     ['roslaunch', 'turtlebot3_navigation', f'{nav_launch_name}.launch'],
        #     preexec_fn=os.setsid,
        #     # stdout=subprocess.DEVNULL,
        #     # stderr=subprocess.DEVNULL
        # )
        
        
        return gazebo_process, nav_process  # 返回两个进程句柄

    except subprocess.CalledProcessError as e:
        print(f"Process execution failed: {e}")
        terminate_gazebo()  # 确保清理已启动的进程
        if 'nav_process' in locals():
            os.killpg(os.getpgid(nav_process.pid), signal.SIGTERM)
        raise
    except Exception as e:
        print(f"Error launching environment {env_name}: {e}")
        raise

def launch_environment1(env_name):
    global gazebo_process
    try:
        # 清理上一个环境
        terminate_gazebo()

        print(f"Launching environment: {env_name}")
        
        # 确保环境变量正确传递
        env = os.environ.copy()
        env['DISPLAY'] = os.getenv('DISPLAY', ':0')
        
        # 启动新的 Gazebo 环境
        gazebo_process = subprocess.Popen(
            ['roslaunch', 'turtlebot3_gazebo', f'{env_name}.launch'],
            env=env,
            preexec_fn=os.setsid,
            stdout=None,
            stderr=None
        )
        
        # 等待环境启动
        time.sleep(5)
        # subprocess.run(['xdotool', 'search', '--name', 'Gazebo', 'windowactivate'])
        return gazebo_process

    except Exception as e:
        print(f"Error launching environment {env_name}: {e}")
        raise

def terminate_gazebo():
    """
    确保完全终止所有 Gazebo 相关进程
    """
    try:
        print("Killing remaining Gazebo processes (if any)...")
        os.system("pkill -9 gzserver")
        os.system("pkill -9 gzclient")
        os.system("pkill -9 roslaunch")
        # 等待进程完全关闭
        if not wait_for_process_termination(["gzserver", "gzclient", "roslaunch"], timeout=15):
            print("Warning: Some processes are still running.")
    except Exception as e:
        print(f"Error while terminating Gazebo: {e}")

def terminate_nav():
    global nav_process
    if nav_process and nav_process.poll() is None:
        os.killpg(os.getpgid(nav_process.pid), signal.SIGTERM)
        nav_process.wait()  # 等待进程真正结束
        print("Navigation process terminated.")
        _wait_for_termination(nav_process, timeout=5)

def nav_start(nav_launch_name):
    global nav_process
    nav_process = subprocess.Popen(
        ['roslaunch', 'turtlebot3_navigation', f'{nav_launch_name}.launch'],
        preexec_fn=os.setsid,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    if wait_for_topic("/move_base/status", GoalStatusArray, timeout=15):
        rospy.loginfo(" 导航核心服务已就绪")
    else:
        rospy.logwarn(" 部分功能未初始化，继续执行可能存在风险")
    

def wait_for_process_termination(process_names, timeout=10):
    """
    等待指定的进程全部终止
    :param process_names: 要检查的进程名称列表（如 ['gzserver', 'gzclient', 'roslaunch']）
    :param timeout: 最大等待时间（秒）
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        still_running = False
        for process_name in process_names:
            result = subprocess.run(
                ["pgrep", "-f", process_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            if result.returncode == 0:  # 进程仍在运行
                still_running = True
                break
        if not still_running:
            print(f"All processes ({process_names}) terminated.")
            return True
        time.sleep(0.1)  # 每 0.5 秒检查一次
    print(f"Timeout waiting for processes ({process_names}) to terminate.")
    return False

def wait_for_topic(topic_name, topic_type, timeout=30):
    try:
        rospy.wait_for_message(topic_name,  topic_type, timeout)
        return True 
    except rospy.ROSException:
        return False
    
def _wait_for_termination(proc, timeout=5):
    """等待进程终止，支持超时和状态轮询"""
    start_time = time.time() 
    while time.time()  - start_time < timeout:
        if proc.poll()  is not None:  # 进程已终止 
            print("导航进程已确认终止")
            return 
        time.sleep(0.1) 
    print(f"超时：进程未在 {timeout} 秒内终止，尝试强制终止")
    os.killpg(os.getpgid(proc.pid),  signal.SIGKILL)

def fixed_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 如果你使用GPU
    torch.cuda.manual_seed_all(seed)  # 如果你有多个GPU
    torch.backends.cudnn.deterministic = True  # 设置为True以确保结果可重复
    torch.backends.cudnn.benchmark = False  # 设置为False以提高结果可重复性
    np.random.seed(seed)
    random.seed(seed)

def hard_update(target, source):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(param.data)

if __name__ == '__main__':

    rospy.init_node('ddpg_train')
    init_plotting()
    for i in [0,5,10,15,20]:
        
        fixed_seed(i)
        tasks = config_test.task
        run_training(tasks)
        print("11111111111111")