import copy
import numpy as np
import rospy
from std_msgs.msg import Float32
# ---Run agent---#

from noises import OUNoise
from mem_buffer import MemoryBuffer
from environments_paper2 import Env
from kgagents import DDPGAgent
import config
from colorama import Fore, Style
import wandb
import random  
import torch
import subprocess
import os
import time
import signal
import pandas as pd
import swanlab
import pdb
gazebo_process = None

def init_plotting():
    config_dict = {key: value for key, value in config.__dict__.items() if not key.startswith("__")}

    # wandb.init(
    #     project = "ddpg_turtlebot",
    #     entity="qinpengdeyouxiang-chongqing-university",
    #     tags = ["DDPG", "TURTLEBOT", "RL"],
    #     config = config_dict,
    # )
    
    # wandb.define_metric("steps")
    # wandb.define_metric("episodes")
    # wandb.define_metric("critic_loss", step_metric = "steps")
    # wandb.define_metric("actor_loss", step_metric = "steps")
    # wandb.define_metric("average_reward", step_metric = "episodes")
    # wandb.define_metric("episode_reward", step_metric = "episodes")
    # wandb.define_metric("avg_reach_rate", step_metric = "episodes")
    
    swanlab.init(
    # 设置项目名
    project="ICMA",
    experiment_name=config.experiment_name,
    # 设置超参数
    config = config_dict,
    )

def run_training(tasks):
    global pub_average_reward, pub_episode_reward
    print('State Dimensions: ' + str(config.STATE_DIMENSION))
    print('Action Dimensions: ' + str(config.ACTION_DIMENSION))
    print('Action Max: ' + str(config.ACTION_V_MAX) + ' m/s and ' + str(config.ACTION_W_MAX) + ' rad/s')
    
    memory_buffer = MemoryBuffer(config.MAX_BUFFER)
    
    agent = DDPGAgent(config.STATE_DIMENSION, 
                        config.ACTION_DIMENSION, 
                        config.ACTION_V_MAX,
                        config.ACTION_W_MAX, 
                        memory_buffer,
                        path_save=config.MODEL_SAVE_PATH,
                        path_load = config.MODEL_LOAD_PATH)
    
    if config.LOAD_PRETRAINED:
        agent.load_models(config.STEPS_TO_LOAD)
        print("--------------- Loaded Model ------------------")
        
    
    noise = OUNoise(config.ACTION_DIMENSION, 
                    max_sigma = 0.1, 
                    min_sigma = 0.1, 
                    decay_period = 100000)
    
    # env = Env(action_dim = config.ACTION_DIMENSION)
    
    steps = 0
    ep1=0
    task_index=config.task_init_index
    for task, task_id in tasks:
        
        task_steps=0
        print(f"---------------------- STARTING TASK {task_id} --------------------")
        
        # Launch Gazebo environment for the task
        launch_environment(task)
        env = Env(action_dim = config.ACTION_DIMENSION)
        env.respawn_goal.stage=task_id
        rewards_all_episodes = []
        gaol_reach_all_episodes =[]
        # agent.ewc.load_fisher_matrix("/home/robot/DDPG_AMR_Control/savemodels/stagec_ewcddpg_1/save_fisher_3/fisher_ma.pth")

        for ep in range(config.MAX_EPISODES[task_index]):
            print(f"---------------------- EPISODE {ep + 1} --------------------")
            done = False
            state = env.reset()
            rewards_current_episode = 0.0
            past_action = np.zeros(config.ACTION_DIMENSION)
            episode_steps = 0
            ep1=ep1+1

            while not done:
                steps += 1
                task_steps+=1
                episode_steps += 1
                state = np.float32(state)
            
                action,qv = agent.hybrid_action_hynet(state)
                
                
                N = copy.deepcopy(noise.get_noise(t = task_steps))
                N[0] = N[0] * config.ACTION_V_MAX / 4.0
                N[1] = N[1] * config.ACTION_W_MAX
                if config.ALLOW_REVERSE:
                    action[0] = np.clip(action[0] + N[0], -config.ACTION_V_MAX, config.ACTION_V_MAX)
                else:
                    action[0] = np.clip(action[0] + N[0], 0.1, config.ACTION_V_MAX)
                action[1] = np.clip(action[1] + N[1], -config.ACTION_W_MAX, config.ACTION_W_MAX)
                

                next_state, reward, done = env.step(action, past_action)
                rewards_current_episode += reward
                next_state = np.float32(next_state)
                agent.memory_buffer.add(state, action, reward, next_state, done,agent.ks_action_save)
                agent.memory_buffer.add_pm(state,action,qv)
                state = copy.deepcopy(next_state)
                
                # print("step: {} | reward: {} | done: {} | action: {},{}".format(steps, reward, done, action[0], action[1]))
                
                past_action = copy.deepcopy(action)
                
                if(steps % config.LEARN_RATE == 0 and task_steps > config.MIN_BUFFER_SIZE):
                    for i in range(20):
                        agent.learn()
                        # print(f"{Fore.BLUE}-------------------- Agent Learning ---------------{Style.RESET_ALL}")
                        
                if config.MAX_STEPS[task_index] <= episode_steps:
                    done = True
                
                if(steps % config.TARGET_UPDATE_RATE == 0 and task_steps > config.MIN_BUFFER_SIZE):
                    agent.update_target()
                    # print(f"{Fore.RED}-------------------- Updating Target Networks ---------------{Style.RESET_ALL}")
                    
                if (steps % config.NETWORK_SAVE_RATE == 0 and task_steps > config.MIN_BUFFER_SIZE):
                    agent.save_models(steps)
                    print(f"{Fore.GREEN}-------------------- SAVING THE MODEL ---------------{Style.RESET_ALL}")
                    print("save_model_steps,tasks",steps,task_id+1)
                    

            rewards_all_episodes.append(rewards_current_episode)
            gaol_reach_all_episodes.append(env.reach_score)
            if ep<100:
                avg_reward= np.sum(rewards_all_episodes[max(0, ep - 100):(ep + 1)])/100
                avg_reach_rate = np.sum(gaol_reach_all_episodes[max(0, ep - 100):(ep + 1)])/100
            else:
                avg_reward = np.mean(rewards_all_episodes[max(0, ep - 100):(ep + 1)])
                avg_reach_rate = np.mean(gaol_reach_all_episodes[max(0, ep - 100):(ep + 1)])
            
            swanlab.log({"episodes": ep1,
                    "episode_reward": rewards_current_episode,
                    "average_reward": avg_reward,
                    "avg_reach_rate": avg_reach_rate,
                    "collision_num":env.collision_num,
                    "goal_reach_num":env.goal_reach_num,
                    'theta1':agent.hybridnet.theta1.data,
                    'steps': steps})
            
            
            print("------------------------------------- EPISODE END -----------------------------------------".format(ep + 1))
        

        task_index=task_index+1
        agent.p_critic_learn()
        agent.qt_reset()
        init_weight_v = torch.tensor([config.init_weight_v]).to(agent.device)
        agent.hybridnet.theta1.data.copy_(init_weight_v)
        agent.memory_buffer=MemoryBuffer(config.MAX_BUFFER)


    print('Completed Training')
    print("saving...")
    agent.save_models(steps)
    print("saved")



def launch_environment(env_name):
    global gazebo_process
    try:
        # 清理上一个环境
        terminate_gazebo()

        print(f"Launching environment: {env_name}")
        
        # 确保环境变量正确传递
        env = os.environ.copy()
        env['DISPLAY'] = os.getenv('DISPLAY', ':0')
        
        # 启动新的 Gazebo 环境
        gazebo_process = subprocess.Popen(
            ['roslaunch', 'turtlebot3_gazebo', f'{env_name}.launch'],
            env=env,
            preexec_fn=os.setsid,
            stdout=None,
            stderr=None
        )
        
        # 等待环境启动
        time.sleep(5)
        # subprocess.run(['xdotool', 'search', '--name', 'Gazebo', 'windowactivate'])
        return gazebo_process

    except Exception as e:
        print(f"Error launching environment {env_name}: {e}")
        raise

def terminate_gazebo():
    """
    确保完全终止所有 Gazebo 相关进程
    """
    try:
        print("Killing remaining Gazebo processes (if any)...")
        os.system("pkill -9 gzserver")
        os.system("pkill -9 gzclient")
        os.system("pkill -9 roslaunch")
        # 等待进程完全关闭
        if not wait_for_process_termination(["gzserver", "gzclient", "roslaunch"], timeout=10):
            print("Warning: Some processes are still running.")
    except Exception as e:
        print(f"Error while terminating Gazebo: {e}")


def wait_for_process_termination(process_names, timeout=10):
    """
    等待指定的进程全部终止
    :param process_names: 要检查的进程名称列表（如 ['gzserver', 'gzclient', 'roslaunch']）
    :param timeout: 最大等待时间（秒）
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        still_running = False
        for process_name in process_names:
            result = subprocess.run(
                ["pgrep", "-f", process_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            if result.returncode == 0:  # 进程仍在运行
                still_running = True
                break
        if not still_running:
            print(f"All processes ({process_names}) terminated.")
            return True
        time.sleep(0.5)  # 每 0.5 秒检查一次
    print(f"Timeout waiting for processes ({process_names}) to terminate.")
    return False

def fixed_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 如果你使用GPU
    torch.cuda.manual_seed_all(seed)  # 如果你有多个GPU
    torch.backends.cudnn.deterministic = True  # 设置为True以确保结果可重复
    torch.backends.cudnn.benchmark = False  # 设置为False以提高结果可重复性
    np.random.seed(seed)
    random.seed(seed)

if __name__ == '__main__':
    rospy.init_node('ddpg_train')
    fixed_seed(config.randseed)
    init_plotting()
    tasks = config.task
    run_training(tasks)