#!/usr/bin/env python
#################################################################################
# Copyright 2018 ROBOTIS CO., LTD.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#################################################################################

# Authors: Gilbert #

import rospy
import random
import time
import os
from gazebo_msgs.srv import SpawnModel, DeleteModel
from gazebo_msgs.msg import ModelStates
from geometry_msgs.msg import Pose
import config
from rospkg import RosPack
import numpy as np
import torch
def fixed_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 如果你使用GPU
    torch.cuda.manual_seed_all(seed)  # 如果你有多个GPU
    torch.backends.cudnn.deterministic = True  # 设置为True以确保结果可重复
    torch.backends.cudnn.benchmark = False  # 设置为False以提高结果可重复性
    np.random.seed(seed)
    random.seed(seed)

class Respawn():
    def __init__(self):
        rp = RosPack()
        fixed_seed(config.randseed)
        self.f = open(rp.get_path('turtlebot3_gazebo') + '/models/turtlebot3_square/goal_box/model.sdf', 'r')
        self.model = self.f.read()
        self.stage = 1
        
        self.goal_position = Pose()
        self.obstacle_1 = 0.6, 0.6
        self.obstacle_2 = 0.6, -0.6
        self.obstacle_3 = -0.6, 0.6
        self.obstacle_4 = -0.6, -0.6

        if self.stage == 1:  
            self.init_goal_x = 0.5
            self.init_goal_y = 0.0
        if self.stage == 2:  
            self.init_goal_x = 1.4
            self.init_goal_y = 0.7
        if self.stage == 3:  
            self.init_goal_x = 1.03
            self.init_goal_y = 0.7
        if self.stage == 4:  
            self.init_goal_x = 1.2
            self.init_goal_y = 0.0
        if self.stage == 5:  
            self.init_goal_x = 1.3
            self.init_goal_y = 0.0
        if self.stage == 6:  
            self.init_goal_x = 1.5
            self.init_goal_y = 0.0

        self.goal_position.position.x = self.init_goal_x
        self.goal_position.position.y = self.init_goal_y
        self.modelName = 'goal'
        self.last_goal_x = self.init_goal_x
        self.last_goal_y = self.init_goal_y
        self.last_index = 0
        self.sub_model = rospy.Subscriber('gazebo/model_states', ModelStates, self.checkModel)
        self.check_model = False
        self.index = 0

    def checkModel(self, model):
        self.check_model = False
        for i in range(len(model.name)):
            if model.name[i] == "goal":
                self.check_model = True

    def respawnModel(self):
        while True:
            if not self.check_model:
                rospy.wait_for_service('gazebo/spawn_sdf_model')
                spawn_model_prox = rospy.ServiceProxy('gazebo/spawn_sdf_model', SpawnModel)
                spawn_model_prox(self.modelName, self.model, 'robotos_name_space', self.goal_position, "world")
                rospy.loginfo("Goal position : %.1f, %.1f", self.goal_position.position.x,
                              self.goal_position.position.y)
                break
            else:
                pass

    def deleteModel(self):
        while True:
            if self.check_model:
                rospy.wait_for_service('gazebo/delete_model')
                del_model_prox = rospy.ServiceProxy('gazebo/delete_model', DeleteModel)
                del_model_prox(self.modelName)
                break
            else:
                pass

    def getPosition(self, position_check=False, delete=False, running=False):
        if delete:
            self.deleteModel()

        if self.stage == 1:
            
            # goal_x_list = [0.874355, -0.874355, 0, 0 ,1.7, 1.7, -1.6, -1.58, 1.1, 1.1, -1.2,-1.22,1.4,1.4]
            # goal_y_list = [0, 0, -0.87, 0.87, -1.7, 1.5, -1.4, 1.8, 1.1, -1.1, -1.2,1.22,1.35,-1.35]
            # aux_index = random.randrange(0, len(goal_x_list))
            # self.goal_position.position.x = goal_x_list[aux_index]+random.uniform(-0.1,0.1) 
            # self.goal_position.position.y = goal_y_list[aux_index]+random.uniform(-0.1,0.1) 

            # while position_check:
            #     goal_x = random.randrange(-12, 13) / 10.0
            #     goal_y = random.randrange(-12, 13) / 10.0
            #     if abs(goal_x - self.obstacle_1[0]) <= 0.4 and abs(goal_y - self.obstacle_1[1]) <= 0.4:
            #         position_check = True
            #     elif abs(goal_x - self.obstacle_2[0]) <= 0.4 and abs(goal_y - self.obstacle_2[1]) <= 0.4:
            #         position_check = True
            #     elif abs(goal_x - self.obstacle_3[0]) <= 0.4 and abs(goal_y - self.obstacle_3[1]) <= 0.4:
            #         position_check = True
            #     elif abs(goal_x - self.obstacle_4[0]) <= 0.4 and abs(goal_y - self.obstacle_4[1]) <= 0.4:
            #         position_check = True
            #     elif abs(goal_x - 0.0) <= 0.4 and abs(goal_y - 0.0) <= 0.4:
            #         position_check = True
            #     else:
            #         position_check = False

            #     if abs(goal_x - self.last_goal_x) < 1 and abs(goal_y - self.last_goal_y) < 1:
            #         position_check = True

            #     self.goal_position.position.x = goal_x
            #     self.goal_position.position.y = goal_y

            goal_x_list=[0.5,0.3, 0.5 ,  0 ,-0.5,-0.4 ,1.5 ,1.9 ,2.5 ,2.4,-1.4,-0.5]
            goal_y_list=[0.0,0.7,-0.65,0.55,0.45,-0.75,0.95,-0.62,0.7,-1.2,0.8,-1.2]

            aux_index = random.randrange(0, len(goal_x_list))
            self.goal_position.position.x = goal_x_list[aux_index]+random.uniform(-0.1,0.1) 
            self.goal_position.position.y = goal_y_list[aux_index]+random.uniform(-0.1,0.1)


        if self.stage == 2:
        
            # goal_x_list = [1.053979, 0.725346, 1.559492, 1.477302, 1.665976, 1.576926, 1.175901, 1.682009, 1.547499, 1.638564, 1.637267, 1.535967, 0.443954, 0.335799, 0.263102]
            # goal_y_list = [-1.122977, -0.332471, -0.291238, -0.330033, -0.734655, -1.328935, -1.411599, -1.803747, -1.157146, -1.260181, -1.668954, -1.546023, -1.570976, -1.100776, -1.021737]

            # goal_x_list = [-1.5, -1.2, -1.1, -0.2, -0.3, -1.5, 0.3, 0.5, 0.8, 1.0, 1.2, 1.5, -1.5, 1.5, 1.665976]
            # goal_y_list = [-1.5, -1.2, -1.1, -0.8, -1.5, -0.3, 0.3, 0.5, 0.8, 1.0, 1.2, 1.5, 1.5, -1.5, -0.734655]

            # goal_x_list = [1.5,1.5,0.6,-1.5,-1.5,-0.6,-1.5,-1.5,-0.6,1.5,1.5,0.6,0.0,0.0,1.2,-1.3] #kfddpg
            # goal_y_list = [0.3,1.5,1.2,-0.3,-1.5,-1.2,0.3,1.5,1.2,-0.3,-1.5,-1.2,1.2,-1.3,0.2,-0.2]

            goal_x_list = [1.6,2.1,1.15,1.82,2.72,2.51 ,2.96,3.0  ,2.66 ,2.65,3.12,3.15]
            goal_y_list = [0.7,0.0,-0.7,1.00,0.96,-1.26,0.95,-0.52,-0.67,0.86,0.85,1.11]

            aux_index = random.randrange(0, len(goal_x_list))
            self.goal_position.position.x = goal_x_list[aux_index]+random.uniform(-0.1,0.1) 
            self.goal_position.position.y = goal_y_list[aux_index]+random.uniform(-0.1,0.1)



        if self.stage==3: 


            goal_x_list = [1.03,-1.2, 1.14 ,2.070,1.53,2.0 ,2.5,3.0,3.0  ,2.4,-1.1,2.04]
            goal_y_list = [0.7 , 0.7,-0.71 ,-0.2 ,0.52,1.1 ,0.0,0.7,-0.75,-1.2,0.0,0.6]
            
            aux_index = random.randrange(0, len(goal_x_list))
            self.goal_position.position.x = goal_x_list[aux_index]+random.uniform(-0.1,0.1) 
            self.goal_position.position.y = goal_y_list[aux_index]+random.uniform(-0.1,0.1) 

        if self.stage==4:

            # goal_x_list = [1.3,-1.3, 1.3, 0.9,0,0,1.6,-0.6,-0.3,-1.5,-1.3,1.6,-1.6,-1.5]
            # goal_y_list = [0, 0, -0.2, 1.3,1.3,-1.3,1.4,1.1,1.5,-0.2,-1.7,-1.6,-1.6,0.3]

            goal_x_list = [1.2,-1.07,-1.07 ,1.21,2.14,2.17,2.20,2.46 ,2.04,2.85,2.5,3.16]
            goal_y_list = [0.0, 0.0 , 0.61 ,0.26,0.25,0.61,1.01,-0.25,-0.7,0.62,1.1,-0.65]


            aux_index = random.randrange(0, len(goal_x_list))
            self.goal_position.position.x = goal_x_list[aux_index]+random.uniform(-0.08,0.08) 
            self.goal_position.position.y = goal_y_list[aux_index]+random.uniform(-0.08,0.08)  

        if self.stage==6:

            goal_x_list = [-0.5,-0.8, 0.9, -0.4, -1.5, 0.5, 1.8, 0.5, 1.8, 1.8,1.8]
            goal_y_list = [   0,   0, 1.0,  1.6, -1.0,-2.0,-1.9,-1.8,   0,-1.1,1.0]
            
            aux_index = random.randrange(0, len(goal_x_list))
            self.goal_position.position.x = goal_x_list[aux_index]+random.uniform(-0.08,0.08) 
            self.goal_position.position.y = goal_y_list[aux_index]+random.uniform(-0.08,0.08)  

        if self.stage==5:

            # goal_x_list = [1.5,1.34, 2.53, 2.43,1.5,3.01,3.01,3.0]
            # goal_y_list = [0, 0.97, -0.2, 0.6,-0.7,0.67,1.078,-0.36]

            goal_x_list = [0,0.63, 1.11, 0.8,0,-0.53,-1.49,-1.06,-1.32,-0.25,0.76,-0.23,1.076]
            goal_y_list = [1.14, 1.0, 0, 1.0,-1.14,-1.04,-1.423,0,0.47,1.28,-1.5,-1.12,-0.7]
            
            aux_index = random.randrange(0, len(goal_x_list))
            self.goal_position.position.x = goal_x_list[aux_index]+random.uniform(-0.08,0.08) 
            self.goal_position.position.y = goal_y_list[aux_index]+random.uniform(-0.08,0.08) 


  
        time.sleep(0.5)
        self.respawnModel()

        self.last_goal_x = self.goal_position.position.x
        self.last_goal_y = self.goal_position.position.y

        return self.goal_position.position.x, self.goal_position.position.y

        

