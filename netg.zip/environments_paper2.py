#!/usr/bin/env python
#################################################################################
# Copyright 2018 ROBOTIS CO., LTD.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#################################################################################

# Authors: Gilbert #

import rospy
import numpy as np
import math
from math import pi
from geometry_msgs.msg import Twist, Point, Pose,PoseWithCovarianceStamped,Quaternion,PoseStamped,TransformStamped
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from std_srvs.srv import Empty
import config
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from respawnGoal_custom_worlds_paper2 import Respawn
from actionlib import SimpleActionClient
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import copy
import tf2_ros
import subprocess
import os
import torch
import random
target_not_movable = False
os.environ['ROSCONSOLE_CONFIG_FILE'] = os.path.expanduser('~/.ros/rosconsole.config')
def fixed_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 如果你使用GPU
    torch.cuda.manual_seed_all(seed)  # 如果你有多个GPU
    torch.backends.cudnn.deterministic = True  # 设置为True以确保结果可重复
    torch.backends.cudnn.benchmark = False  # 设置为False以提高结果可重复性
    np.random.seed(seed)
    random.seed(seed)

class Env():
    def __init__(self, action_dim=2):
        fixed_seed(config.randseed)
        self.goal_x = 0
        self.goal_y = 0
        self.heading = 0
        self.initGoal = True
        self.get_goalbox = False
        self.position = Pose()
        self.pub_cmd_vel = rospy.Publisher('cmd_vel', Twist, queue_size=5)
        self.sub_odom = rospy.Subscriber('odom', Odometry, self.getOdometry)
        self.reset_proxy = rospy.ServiceProxy('gazebo/reset_simulation', Empty)
        self.unpause_proxy = rospy.ServiceProxy('gazebo/unpause_physics', Empty)
        self.pause_proxy = rospy.ServiceProxy('gazebo/pause_physics', Empty)
        self.goal_pub = rospy.Publisher('move_base_simple/goal', PoseStamped, queue_size=10)
        self.inpose_pub = rospy.Publisher('/initialpose', PoseWithCovarianceStamped, queue_size=1)
        self.respawn_goal = Respawn()
        self.past_distance = 0.
        self.stopped = 0
        self.action_dim = action_dim
        self.collision_num=0
        self.goal_reach_num=0
        self.reach_score=0
        self.yaw=0
        
        # self.move_base_client = SimpleActionClient('move_base', MoveBaseAction)
        # rospy.wait_for_service('/move_base/clear_costmaps')
        # self.clear_costmaps_proxy = rospy.ServiceProxy('/move_base/clear_costmaps', Empty)

        # self.tf_buffer = tf2_ros.Buffer()
        # self.tf_listener = tf2_ros.TransformListener(self.tf_buffer)

        # self.tf_initialize()
        # self.timer = rospy.Timer(rospy.Duration(0.05), self.publish_static_transform)
        # Keys CTRL + c will stop script
        rospy.on_shutdown(self.shutdown)

    def shutdown(self):
        rospy.loginfo("Stopping TurtleBot")
        self.pub_cmd_vel.publish(Twist())
        rospy.sleep(0.1)

    def getGoalDistace(self):
        goal_distance = round(math.hypot(self.goal_x - self.position.x, self.goal_y - self.position.y), 2)
        self.past_distance = goal_distance
        return goal_distance

    def getOdometry(self, odom):
        self.past_position = copy.deepcopy(self.position)
        self.position = odom.pose.pose.position
        orientation = odom.pose.pose.orientation
        orientation_list = [orientation.x, orientation.y, orientation.z, orientation.w]
        _, _, yaw = euler_from_quaternion(orientation_list)

        goal_angle = math.atan2(self.goal_y - self.position.y, self.goal_x - self.position.x)
        heading = goal_angle - yaw

        if heading > pi:
            heading -= 2 * pi

        elif heading < -pi:
            heading += 2 * pi

        self.heading = round(heading, 3)
        self.yaw=yaw
        
        ###########################发布odom->map


    def getState(self, scan, past_action):
        scan_range = []
        heading = self.heading
        min_range = 0.136
        done = False

        for i in range(len(scan.ranges)):
            if scan.ranges[i] == float('Inf') or scan.ranges[i] == float('inf'):
                scan_range.append(3.5)
            elif np.isnan(scan.ranges[i]) or scan.ranges[i] == float('nan'):
                scan_range.append(0)
            else:
                scan_range.append(scan.ranges[i])

        if min_range > min(scan_range) > 0:
            done = True

        for pa in past_action:
            scan_range.append(pa)

        current_distance = round(math.hypot(self.goal_x - self.position.x, self.goal_y - self.position.y), 2)

        if current_distance < 0.15:
            self.get_goalbox = True


        return scan_range + [heading, current_distance], done

    
    def setReward(self, state, done):
        """

        :param state:
        :param done:
        :return:
        """
        # relative euclidean distance of the robot from current position to the goal
        current_distance = state[-1]

        # angular direction of the robot's movement
        heading = state[-2]

        # difference of the past distance and current distance
        distance_rate = (self.past_distance - current_distance)

        # closing in towards the goal as current_distance is lesser than the past
        if distance_rate > 0:
            reward = 200.0 * distance_rate

        # if moving further awaye
        if distance_rate <= 0:
            reward = -8.0

        self.past_distance = current_distance

        # Collision logic
        # If it is found in the same position for 20 time frames,
        # then it is declared to be collided and the episode ends.
        a, b, c, d = float('{0:.3f}'.format(self.position.x)), float('{0:.3f}'.format(self.past_position.x)), float(
            '{0:.3f}'.format(self.position.y)), float('{0:.3f}'.format(self.past_position.y))
        if a == b and c == d:
            self.stopped += 1
            if self.stopped == 20:
                rospy.loginfo('Robot is in the same position, 20 times in a row')
                rospy.loginfo('Robot is in the same position, 20 times in a row')
                self.stopped = 0
                done = True
        else:
            self.stopped = 0

        if done:
            rospy.loginfo("Collision!!")
            self.reach_score=0
            self.collision_num=self.collision_num+1
            reward = config.Collision
            self.pub_cmd_vel.publish(Twist())
            

        # If goal is reached
        if self.get_goalbox:
            rospy.loginfo("Goal!!")
            self.reach_score=1
            self.goal_reach_num=self.goal_reach_num+1
            done = True
            reward = config.GOAL_REACH_REWARD
            self.pub_cmd_vel.publish(Twist())

            # Reset the goal in the environment
            # self.goal_x, self.goal_y = self.respawn_goal.getPosition(True, delete=True, running=True)
            # self.goal_distance = self.getGoalDistace()
            self.get_goalbox = False

        return reward, done

    def step(self, action, past_action):
        linear_vel = action[0]
        ang_vel = action[1]

        vel_cmd = Twist()
        vel_cmd.linear.x = linear_vel
        vel_cmd.angular.z = ang_vel
        self.pub_cmd_vel.publish(vel_cmd)

        data = None
        while data is None:
            try:
                data = rospy.wait_for_message('scan', LaserScan, timeout=5)
            except:
                pass

        state, done = self.getState(data, past_action)
        reward, done = self.setReward(state, done)
        return np.asarray(state), reward, done

    def reset(self):
        print("waiting for service")
        rospy.wait_for_service('gazebo/reset_simulation')
        try:
            self.reset_proxy()
        except (rospy.ServiceException) as e:
            print("gazebo/reset_simulation service call failed")

        
        # try:
        #     self.reset_navigation()
        # except rospy.ServiceException as e:
        #     rospy.logerr(f"Reset failed: {e}")

        print("reset called")
        # self.publish_static_transform()
        self.reach_score=0
        data = None
        while data is None:
            try:
                data = rospy.wait_for_message('scan', LaserScan, timeout=5)
            except:
                pass
        
        #self.restart_navigation() ######################################################3   ############

        if self.initGoal:
            self.goal_x, self.goal_y = self.respawn_goal.getPosition()
            self.initGoal = False
        else:
            self.goal_x, self.goal_y = self.respawn_goal.getPosition(True, delete=True)

        rospy.sleep(0.2)
        self.goal_distance = self.getGoalDistace()
        self.set_initial_pose(self.position.x,self.position.y,self.yaw)
        state, _ = self.getState(data, [0] * self.action_dim)

        print(self.goal_x, self.goal_y)

        self.pub_goal()

        return np.asarray(state)
    
    def set_initial_pose(self, x, y, yaw):
        """设置AMCL初始位置"""
        
        pose = PoseWithCovarianceStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = rospy.Time.now()
        pose.pose.pose.position = Point(x, y, 0)
        q = quaternion_from_euler(0, 0, yaw)
        pose.pose.pose.orientation = Quaternion(*q)
        pose.pose.covariance = [0.25]*6 + [0.0]*30  # 典型协方差值
        self.inpose_pub.publish(pose)
        rospy.sleep(3)

    def pub_goal(self):
        """设置AMCL初始位置"""
        
        goal = PoseStamped()
        goal.header.stamp = rospy.Time.now()
        goal.header.frame_id = "map"
        goal.pose.position.x = self.goal_x  # 目标点的x坐标
        goal.pose.position.y = self.goal_y  # 目标点的y坐标
        goal.pose.position.z = 0.0  # 目标点的z坐标（地面机器人通常为0）

        goal_angle = math.atan2(self.goal_y - self.position.y, self.goal_x - self.position.x)

        q = quaternion_from_euler(0, 0, goal_angle)
        goal.pose.orientation = Quaternion(*q)
        # goal.pose.orientation.w = 1.0  # 四元数的w分量，表示没有旋转
        # goal.pose.orientation.x = 0.0
        # goal.pose.orientation.y = 0.0
        # goal.pose.orientation.z = 0.0

        self.goal_pub.publish(goal)


    # def restart_navigation(self):
    #     """完全重启导航堆栈"""
    #     try:
    #         # 终止导航相关节点
    #         subprocess.call(["rosnode", "kill", "/move_base"])
            
    #         rospy.sleep(1)
            
    #         # 重新启动节点
    #         subprocess.Popen(["roslaunch", "turtlebot3_navigation", 
    #                         "move_base2.launch"])

    #         rospy.loginfo("Navigation stack restarted.")
            
    #     except Exception as e:
    #         rospy.logerr("Restart failed: "+str(e))

    #         # 等待关键系统就绪
    #     if self.wait_for_tf():
    #         rospy.loginfo("System ready.")
    #     else:
    #         rospy.logerr("TF stabilization timeout!")
        
    #     # 发布目标前最终检查

    def tf_initialize(self):
        """Initialize the StaticTransformBroadcaster and other parameters."""
        # Static transform broadcaster
        self.static_broadcaster = tf2_ros.StaticTransformBroadcaster()

        # Initialize static transformation message
        self.static_transform = TransformStamped()
        self.static_transform.header.frame_id = "map"
        self.static_transform.child_frame_id = "odom"
        self.static_transform.transform.translation.x = 0.0
        self.static_transform.transform.translation.y = 0.0
        self.static_transform.transform.translation.z = 0.0
        self.static_transform.transform.rotation.x = 0.0
        self.static_transform.transform.rotation.y = 0.0
        self.static_transform.transform.rotation.z = 0.0
        self.static_transform.transform.rotation.w = 1.0

        # Publish the initial static transform
        self.publish_static_transform()
    
    def publish_static_transform(self):
        # Publish the static transform every time the system is initialized or reset
        self.static_transform.header.stamp = rospy.Time.now()
        self.static_broadcaster.sendTransform(self.static_transform)

    def restart_navigation(self):
   
        try:
            # 终止导航相关节点
            subprocess.call(["rosnode", "kill", "/move_base"])

            
            
            rospy.sleep(1)  # 等待一下，确保节点完全终止

            # 重新启动节点，并传递参数
            subprocess.Popen(["roslaunch", "turtlebot3_navigation", "move_base2.launch",
                            "robot:=turtlebot3_burger",  # 设置 robot 参数
                            "global_planner:='' ",  # 设置 global_planner 参数
                            "local_planner:=pid",
                            'use_sim_time:=true'],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)  # 设置 local_planner 参数
            

            
            rospy.loginfo("Navigation stack restarted.")
            
        except Exception as e:
            rospy.logerr("Restart failed: "+str(e))

        # 等待关键系统就绪
        if self.wait_for_tf():
            rospy.loginfo("System ready.")
        else:
            rospy.logerr("TF stabilization timeout!")

    def wait_for_tf(self):
        """等待关键坐标系可用"""
        tf_buffer = tf2_ros.Buffer()
        listener = tf2_ros.TransformListener(tf_buffer)
        rate = rospy.Rate(10)
        timeout = rospy.Time.now() + rospy.Duration(5)
        
        while not rospy.is_shutdown() and rospy.Time.now() < timeout:
            try:
                # 检查map到base_link的变换是否可用
                trans = tf_buffer.lookup_transform('map', 'base_link',
                                                rospy.Time(0))
                rospy.loginfo("TF stabilized.")
                return True
            except (tf2_ros.LookupException, 
                    tf2_ros.ConnectivityException,
                    tf2_ros.ExtrapolationException):
                rate.sleep()
        return False


    def clear_tf(self):
        # 使用 tf2_ros 清除所有 TF 数据
        self.tf_buffer.clear()

        


        

