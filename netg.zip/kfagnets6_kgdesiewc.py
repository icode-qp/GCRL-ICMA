#!/usr/bin/env python

import rospy
import os
import sys

from std_msgs.msg import Float32
import torch
import torch.nn.functional as F
from torch import nn
from geometry_msgs.msg import Twist

import config
from models_big import Actor, Critic
import math
from fcfuzzypro import Fuzzy_Actor
# ---Functions to make network updates---#
import random
import numpy as np
import pdb
def soft_update(target, source, tau):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(target_param.data * (1.0 - tau) + param.data * tau)


def hard_update(target, source):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(param.data)

def fixed_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 如果你使用GPU
    torch.cuda.manual_seed_all(seed)  # 如果你有多个GPU
    torch.backends.cudnn.deterministic = True  # 设置为True以确保结果可重复
    torch.backends.cudnn.benchmark = False  # 设置为False以提高结果可重复性
    np.random.seed(seed)
    random.seed(seed)

class hybrid_net(torch.nn.Module):
    def __init__(self,model_num,action_dim,action_v_max,action_w_max):
        super(hybrid_net, self).__init__()
        self.model_num=model_num
        self.action_w_max=action_w_max
        self.action_v_max=action_v_max

        self.theta1 = nn.Parameter(torch.tensor([[0.0]]))
        # self.theta2 = nn.Parameter(torch.tensor([[0.0]])).requires_grad = False  


    def forward(self,x):
        # self.hy_v_layer.weight.data.copy_(self.hy_w_layer.weight.data)
        
        action_v=x[:,0].unsqueeze(1)*self.theta1  +  x[:,2].unsqueeze(1)*(1-self.theta1)
        action_w=x[:,1].unsqueeze(1)*self.theta1 + x[:,3].unsqueeze(1)*(1-self.theta1)
        action = torch.cat((action_v,action_w),dim=1)

        return action
    


class DDPGAgent:

    def __init__(self,state_dim, action_dim, action_v_max, action_w_max, memory_buffer = None, path_save = "models", path_load = "models"):
        torch.set_default_tensor_type('torch.cuda.FloatTensor' if torch.cuda.is_available() else 'torch.FloatTensor')
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.action_v_max = action_v_max
        self.action_w_max = action_w_max
        self.memory_buffer = memory_buffer
        self.is_cuda_available = torch.cuda.is_available()
        self.device = torch.device("cuda" if self.is_cuda_available else "cpu")
        
        fixed_seed(config.randseed)

        self.actor = Actor(self.state_dim, self.action_dim, self.action_v_max, self.action_w_max).to(self.device)
        self.target_actor = Actor(self.state_dim, self.action_dim, self.action_v_max, self.action_w_max).to(self.device)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), config.ACTOR_LR)

        self.critic = Critic(self.state_dim, self.action_dim).to(self.device)
        self.target_critic = Critic(self.state_dim, self.action_dim).to(self.device)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), config.CRITIC_LR)
        
        self.pub_qvalue = rospy.Publisher('qvalue', Float32, queue_size=5)
        self.sub_vel=rospy.Subscriber("/cmd_vel_wb", Twist, self.vel_callback)
        
        self.qvalue = Float32()
        self.path_save = path_save
        self.path_load = path_load
        self.batch_size=config.BATCH_SIZE
        self.batch_size_old=config.BATCH_SIZE_OLD
        self.critic_loss = -1
        self.actor_loss = -1
        self.hybrid_loss = 0.0
        self.flag=0
        self.cr_update_num=0
        self.ks_Q=0.0
        self.ks_action_save=[]
        self.u_action_save=[]
        self.h_action_save=[]
        
        self.u_q=0.0
        self.target_q=0.0
        self.theta_t=config.theta_t

        self.ks_v=0
        self.ks_w=0
        self.clone_p=config.clone_p
        self.clone_p_old=config.clone_p_old
        hard_update(self.target_actor, self.actor)
        hard_update(self.target_critic, self.critic)

        self.ref_actor = Actor(self.state_dim, self.action_dim, self.action_v_max, self.action_w_max).to(self.device)
        self.ref_actor.load_state_dict(torch.load(f"{self.path_load}/save_agent_{config.steps}/actor.pt"))

        ################################################################################################

        # self.knowledge_system=knowledge_system(config.proposition_base,['v','w'])

        self.hybridnet=hybrid_net(2,2,self.action_v_max ,
                        self.action_w_max).to(self.device)
        
        self.target_hybridnet=hybrid_net(2,2,self.action_v_max ,
                        self.action_w_max).to(self.device)

        init_weight_v = torch.tensor([config.init_weight_v]).to(self.device)
        init_weight_w = torch.tensor([config.init_weight_w]).to(self.device)

        self.hybridnet.theta1=nn.Parameter(init_weight_v)
        # self.hybridnet.theta2=nn.Parameter(init_weight_w)

        hard_update(self.target_hybridnet, self.hybridnet)

        for name, param in self.hybridnet.named_parameters():
            print(f"Layer: {name} | Weight shape: {param}")
            print(param.shape)


        self.hybridnet_optimizer = torch.optim.Adam(
            self.hybridnet.parameters(), lr=config.hybridnet_lr)
        
        
        self.ep_num=0

        self.ewc = EWC(self.actor, self.memory_buffer, self.device)
        self.bl=config.ewc_rate

        self.si= SynapticConsolidation(self.actor,damping=0.001)


        self.theta_ref=0
        self.simlar_cof=self.hybridnet.theta1.detach()
        #################################################################################################
        self.fcfuzzymodel=Fuzzy_Actor(self.state_dim, self.action_dim, self.action_v_max, self.action_w_max).to(self.device)
        self.fuzzy_optimizer = torch.optim.Adam(
            self.fcfuzzymodel.parameters(), lr=config.fuzzy_lr)


    def get_action(self, state):
        state = torch.from_numpy(state).to(self.device)
        action = self.actor.forward(state).detach()
        self.u_action_save=action.squeeze(0).cpu().numpy()
        return action.data.cpu().numpy()

    def learn(self):

        s_sample, a_sample, r_sample, new_s_sample, done_sample,ks_a_sample,index_sample,weight_sample= self.memory_buffer.sample(self.batch_size)

        s_sample = torch.from_numpy(s_sample).to(self.device)
        a_sample = torch.from_numpy(a_sample).to(self.device)
        r_sample = torch.from_numpy(r_sample).to(self.device)
        new_s_sample = torch.from_numpy(new_s_sample).to(self.device)
        done_sample = torch.from_numpy(done_sample).to(self.device)
        ks_a_sample = torch.from_numpy(ks_a_sample).to(self.device)
        index_sample= torch.from_numpy(index_sample).to(self.device)
        weight_sample =torch.from_numpy(weight_sample).to(self.device)


        ################################################################################################################

        policy_actions_no_gard = self.actor.forward(s_sample).detach()

        target_actions = self.target_actor.forward(new_s_sample).detach()
        
        self.simlar_cof=self.hybridnet.theta1.detach()
    
        target_critic_values = torch.squeeze(self.target_critic.forward(new_s_sample, target_actions).detach())

        critic_value = torch.squeeze(self.critic.forward(s_sample, a_sample))

        target = r_sample + (1 - done_sample) * config.GAMMA * target_critic_values

        # critic_loss = F.smooth_l1_loss(critic_value, target)

        critic_loss = torch.mean(F.smooth_l1_loss(critic_value, target,reduction='none')*weight_sample)

        self.critic_loss = critic_loss.data.cpu().numpy()
        self.critic_optimizer.zero_grad()
        critic_loss.backward()

        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 2)

        self.critic_optimizer.step()

        ########################################################更新优先级
        td_errors = (critic_value - target).detach().cpu().numpy()
        self.memory_buffer.current_buffer.update_priorities(index_sample, td_errors)
        ########################################################

        # ------------ optimize actor ------------------

        if self.cr_update_num % config.policy_delay==0:

            policy_actions = self.actor.forward(s_sample)


            # actor_loss2 = -torch.mean(self.critic.forward(s_sample, policy_actions)).detach()

            # self.ks_Q = -torch.mean(self.critic.forward(s_sample, ks_a_sample)).detach()

            si_loss = self.si.compute_consolidation_loss(self.actor,self.ewc.old_params)

            clone_loss = (1-self.simlar_cof+self.theta_t)*self.clone_p*(F.mse_loss(policy_actions,ks_a_sample))

            ewc_loss = self.ewc.penalty()
            
            # mem_loss = self.compute_mem_loss()

            actor_loss = -self.simlar_cof*torch.mean(self.critic.forward(s_sample, policy_actions))

            # actor_loss = actor_loss+clone_loss+(ewc_loss+si_loss)/2*self.bl+mem_loss

            actor_loss = actor_loss+clone_loss+(ewc_loss+si_loss)/2*self.bl


            hybrid_action=self.hybridnet(torch.cat((policy_actions_no_gard, ks_a_sample), dim=1))
            
            hybrid_loss= -torch.mean(self.critic.forward(s_sample, hybrid_action))
            
            actor_loss1=(actor_loss+hybrid_loss)

            self.actor_loss = actor_loss.data.cpu().numpy()

            self.hybrid_loss = hybrid_loss.data.cpu().numpy()

            # self.u_q=actor_loss2


            self.actor_optimizer.zero_grad()
            self.hybridnet_optimizer.zero_grad()


            actor_loss1.backward()


            torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 2)
            torch.nn.utils.clip_grad_norm_(self.hybridnet.parameters(), 2)

            self.hybridnet_optimizer.step()
            
            self.actor_optimizer.step()

            for param in self.hybridnet.parameters():
                param.data.clamp_(min=0, max=1.0)

            self.si.update(torch.mean(r_sample))  ###更新si-omega


    def compute_mem_loss(self):

        if not self.memory_buffer.old_task_buffers:
            return 0
        else:
            s_sample_old, a_sample_old, = self.memory_buffer.sample_old(self.batch_size_old)
            s_sample_old=torch.from_numpy(s_sample_old).to(self.device)
            a_sample_old=torch.from_numpy(a_sample_old).to(self.device)
            policy_actions_old = self.actor.forward(s_sample_old)
            return F.mse_loss(policy_actions_old,a_sample_old)*self.clone_p_old
        
        ##############################################################################################

    def hybrid_action(self,state): #用于与环境交互的动作

        action = self.get_action(state)

        state_deal=self.data_deal(state)

        state_deal={'theta':[state_deal[0]],'vis':[state_deal[1]]}

        k_action=self.knowledge_system.knowledge_reason_tensor(state_deal)

        kk_action=k_action.squeeze(0).cpu().numpy()
        

        if k_action==[0]:
            return action
        else:
            if self.ep_num<100:
                m=0.0
                n=1.0
                return m*action+n*kk_action
            
            else:
                return (kk_action+action)/2
    
    def hybrid_action_hynet(self,state): #用于与环境交互的动作

        action = torch.tensor(self.get_action(state),dtype=torch.float32).unsqueeze(0)
        
        state = torch.from_numpy(state).to(self.device)

        k_action = self.ref_actor.forward(state).detach().unsqueeze(0)

        hybrid_action=self.hybridnet(torch.cat((action, k_action), dim=1)).detach().squeeze(0).cpu().numpy()

        self.ks_action_save=k_action.squeeze(0).cpu().numpy()
        self.u_action_save=action.squeeze(0).cpu().numpy()
        self.h_action_save=hybrid_action

        return self.h_action_save
    

    #################################### 测试交替交互
    def hybrid_action_hynet1(self,state,ep): #用于与环境交互的动作

        

        action = torch.tensor(self.get_action(state),dtype=torch.float32).unsqueeze(0)
        
        state=torch.tensor(state)
        
        k_action=torch.tensor([self.ks_v,self.ks_w]).unsqueeze(0)

        hybrid_action=self.hybridnet(torch.cat((action, k_action), dim=1)).detach().squeeze(0).cpu().numpy()

        self.ks_action_save=k_action.squeeze(0).cpu().numpy()
        self.u_action_save=action.squeeze(0).cpu().numpy()
        self.h_action_save=hybrid_action


        if ep % 2==0 or ep>200:
            return self.u_action_save,1
        else:
            return self.ks_action_save,0

    def learn1(self):
        s_sample, a_sample, r_sample, new_s_sample, done_sample,ks_a_sample= self.memory_buffer.sample(config.BATCH_SIZE)

        s_sample = torch.from_numpy(s_sample).to(self.device)
        a_sample = torch.from_numpy(a_sample).to(self.device)
        r_sample = torch.from_numpy(r_sample).to(self.device)
        new_s_sample = torch.from_numpy(new_s_sample).to(self.device)
        done_sample = torch.from_numpy(done_sample).to(self.device)
        ks_a_sample = torch.from_numpy(ks_a_sample).to(self.device)

        ################################################################################################################

        policy_actions_no_gard = self.actor.forward(s_sample).detach()

        target_actions = self.target_actor.forward(new_s_sample).detach()
        
        self.simlar_cof=self.hybridnet.theta1.detach()
    
        target_critic_values = torch.squeeze(self.target_critic.forward(new_s_sample, target_actions).detach())

        critic_value = torch.squeeze(self.critic.forward(s_sample, a_sample))

        target = r_sample + (1 - done_sample) * config.GAMMA * target_critic_values

        critic_loss = F.smooth_l1_loss(critic_value, target)

        self.critic_loss = critic_loss.data.cpu().numpy()
        self.critic_optimizer.zero_grad()
        critic_loss.backward()

        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 2)

        self.critic_optimizer.step()

        # ------------ optimize actor ------------------

        if self.cr_update_num % config.policy_delay==0:

            policy_actions = self.actor.forward(s_sample)

            actor_loss2 = -torch.mean(self.critic.forward(s_sample, policy_actions)).detach()

            self.ks_Q = -torch.mean(self.critic.forward(s_sample, ks_a_sample)).detach()


            # actor_loss = -self.simlar_cof*torch.mean(self.critic.forward(s_sample, policy_actions))+(1-self.simlar_cof+self.theta_t)*self.clone_p*(F.mse_loss(policy_actions,ks_a_sample))+self.ewc.penalty()*self.bl
            
            actor_loss = -torch.mean(self.critic.forward(s_sample, policy_actions))+self.ewc.penalty()*self.bl

            # actor_loss = -torch.mean(self.critic.forward(s_sample, policy_actions))+(self.theta_t)*self.clone_p*(F.mse_loss(policy_actions,ks_a_sample))+self.ewc.penalty()*self.bl

            hybrid_action=self.hybridnet(torch.cat((policy_actions_no_gard, ks_a_sample), dim=1))
            
            hybrid_loss= -torch.mean(self.critic.forward(s_sample, hybrid_action))+(self.hybridnet.theta1-1)**2
            
            actor_loss1=(actor_loss+hybrid_loss)

            self.actor_loss = actor_loss.data.cpu().numpy()

            self.hybrid_loss = hybrid_loss.data.cpu().numpy()

            self.u_q=actor_loss2


            self.actor_optimizer.zero_grad()
            self.hybridnet_optimizer.zero_grad()


            actor_loss1.backward()


            torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 2)
            torch.nn.utils.clip_grad_norm_(self.hybridnet.parameters(), 2)

            self.hybridnet_optimizer.step()
            
            self.actor_optimizer.step()

            for param in self.hybridnet.parameters():
                param.data.clamp_(min=0, max=1.0)


        ##############################################################################################
    ####################################
    
    def index_f(self,theta1_copy,center):

        return 1/(1+torch.exp(-30*(theta1_copy-center)))



    def get_critic_loss(self):
        return self.critic_loss
        
    def get_actor_loss(self):
        return self.actor_loss
        
    def update_target(self):
        soft_update(self.target_actor, self.actor, config.TAU)
        soft_update(self.target_critic, self.critic, config.TAU)
        soft_update(self.target_hybridnet, self.hybridnet, config.TAU)

    def save_models(self, steps):
        if not os.path.isdir(f"{self.path_save}/save_agent_{steps}"):
            os.makedirs(f"{self.path_save}/save_agent_{steps}")
        
        torch.save(self.target_actor.state_dict(), f"{self.path_save}/save_agent_{steps}/actor.pt")
        torch.save(self.target_critic.state_dict(), f"{self.path_save}/save_agent_{steps}/critic.pt")
        torch.save(self.target_hybridnet.state_dict(), f"{self.path_save}/save_agent_{steps}/hybridnet.pt")
        # torch.save(self.fcfuzzymodel.state_dict(), f"{self.path_save}/save_agent_{steps}/fuzzy_actor.pt")
        print('****Models saved***')


    def save_models1(self, task):
        if not os.path.isdir(f"{self.path_save}/save_agent_{task}"):
            os.makedirs(f"{self.path_save}/save_agent_{task}")
        
        torch.save(self.fcfuzzymodel.state_dict(), f"{self.path_save}/save_agent_{task}/fuzzy_actor.pt")
        print('****Models saved***')

    def load_models(self, steps):
        self.actor.load_state_dict(torch.load(f"{self.path_load}/save_agent_{steps}/actor.pt"))
        self.critic.load_state_dict(torch.load(f"{self.path_load}/save_agent_{steps}/critic.pt"))
        self.hybridnet.load_state_dict(torch.load(f"{self.path_load}/save_agent_{steps}/hybridnet.pt"))
        
        hard_update(self.target_actor, self.actor)
        hard_update(self.target_critic, self.critic)
        hard_update(self.target_hybridnet, self.hybridnet)
        print('***Models load***',steps)

    def load_models1(self, steps):
        self.actor.load_state_dict(torch.load(f"{self.path_load}/save_agent_{steps}/actor.pt"))
        self.critic.load_state_dict(torch.load(f"{self.path_load}/save_agent_{steps}/critic.pt"))
        self.hybridnet.load_state_dict(torch.load(f"{self.path_load}/save_agent_{steps}/hybridnet.pt"))
        
        hard_update(self.target_actor, self.actor)
        hard_update(self.target_critic, self.critic)
        hard_update(self.target_hybridnet, self.hybridnet)
        print('***Models load***',steps)


    def get_fcfuzzy_action(self,state):
        state = torch.from_numpy(state).to(self.device).unsqueeze(0)
        action = self.fcfuzzymodel.forward(state).detach()
        return action.squeeze(0).data.cpu().numpy()



    def project_params(self):
        with torch.no_grad():
            self.hybridnet.theta1.data = torch.clamp(self.hybridnet.theta1.data, 0, 1)
            # self.hybridnet.theta2.data = torch.clamp(self.hybridnet.theta2.data, 0, 1)
            sum_theta = self.hybridnet.theta1.data+ self.hybridnet.theta2.data
            if sum_theta != 1:
                self.hybridnet.theta1.data = self.hybridnet.theta1.data / sum_theta
                # self.hybridnet.theta2.data = self.hybridnet.theta2.data / sum_theta

    
    def load_env(self,env):
        self.env_temp=env

    def vel_callback(self, msg):
        """ 处理速度消息的回调函数 """
        # 提取线速度和角速度
        self.ks_v = msg.linear.x    # 前向线速度
        self.ks_w = msg.angular.z   # Z轴角速度（转向）


    def knowledge_extraction(self):
        epchos=800
        for epoch in range(epchos):
            
            
            s_sample, a_sample, r_sample, new_s_sample, done_sample,ks_a_sample= self.memory_buffer.sample(10)
            s_sample = torch.from_numpy(s_sample).to(self.device)
            a_sample = torch.from_numpy(a_sample).to(self.device)
            r_sample = torch.from_numpy(r_sample).to(self.device)
            new_s_sample = torch.from_numpy(new_s_sample).to(self.device)
            done_sample = torch.from_numpy(done_sample).to(self.device)
            ks_a_sample = torch.from_numpy(ks_a_sample).to(self.device)

            self.fuzzy_optimizer.zero_grad()
            policy_actions_no_gard = self.actor.forward(s_sample).detach()
            loss=F.smooth_l1_loss(self.fcfuzzymodel(s_sample), policy_actions_no_gard)
            loss.backward()
            self.fuzzy_optimizer.step()

            # for i in range(100):
            #     self.fuzzy_optimizer.zero_grad()
            #     policy_actions_no_gard = self.actor.forward(s_sample).detach()
            #     loss=F.smooth_l1_loss(self.fcfuzzymodel(s_sample), policy_actions_no_gard)*100
            #     loss.backward()
            #     self.fuzzy_optimizer.step()
            #     if i % 10 == 0:
            #         print(f' epoch{epoch},MSE Loss: {loss.item():.4f}')

            if epoch % 10 == 0:
                print(f'Epoch [{epoch}/{epchos}], MSE Loss: {loss.item():.4f}')

            

class EWC:
    def __init__(self, model, buffer, device='cpu'):
        self.model = model
        self.buffer = buffer
        self.device = device
        self.params = {name: param for name, param in model.named_parameters() if param.requires_grad}
        self.fisher_matrix = {name: torch.zeros_like(param) for name, param in model.named_parameters()}
        self.old_params = None
        self.lab =config.fisher_lab

    def _compute_fisher_matrix(self):
        """
        计算 Fisher 信息矩阵，从 buffer 均匀采样若干批次数据估计梯度平方的期望值。
        """
        fisher = {name: torch.zeros_like(param) for name, param in self.params.items()}
        self.model.eval()

        # 定义采样次数（从 buffer 中采样多个批次）
        sample_batches = 10  # 可以根据需要调整采样次数

        for _ in range(sample_batches):
            states= self.buffer.sample(config.BATCH_SIZE)[0] # 从缓冲区采样 states
            states = torch.from_numpy(states).to(self.device)

            # 计算代理损失
            outputs = self.model.forward(states)
            loss = outputs.mean()  # 使用均值损失作为代理

            # 计算梯度
            self.model.zero_grad()
            loss.backward()

            # 累加梯度平方
            for name, param in self.model.named_parameters():
                if param.requires_grad:
                    fisher[name] += param.grad.pow(2)

        # 对 Fisher 信息归一化（取期望值）
        for name in fisher:
            fisher[name] /= sample_batches  # 取均值

        return fisher

    def consolidate(self):
        """
        保存模型当前参数并计算 Fisher 信息矩阵。
        """
        # 不归一化
        # self.temp = self._compute_fisher_matrix()
        # for name in self.temp:
        #     self.fisher_matrix[name] = self.lab*self.fisher_matrix[name]+self.temp[name]

        #归一化

        self.temp = self._compute_fisher_matrix()
        self.temp = self.normalize_fisher(self.temp)

        for name in self.temp:
            self.fisher_matrix[name] = self.lab*self.fisher_matrix[name]+self.temp[name]
        
        self.fisher_matrix = self.normalize_fisher(self.fisher_matrix )

        self.old_params = {name: param.clone().detach() for name, param in self.params.items()}

    def penalty(self):
        """
        计算 EWC 惩罚项，鼓励模型参数与旧任务参数保持一致。
        """
        if self.fisher_matrix is None or self.old_params is None:
            
            return 0

        penalty = 0
        for name, param in self.params.items():
            fisher = self.fisher_matrix[name]
            old_param = self.old_params[name]
            penalty += (fisher * (param - old_param).pow(2)).sum()
        
        return penalty
    
    def normalize_fisher(self, fisher_param,mode='minmax'):

        norm_fisher=fisher_param

        for name in norm_fisher:
            param = norm_fisher[name]
            if mode == 'minmax':
                min_val, max_val = param.min(), param.max()
                norm_fisher[name] = (param - min_val) / (max_val - min_val + 1e-8)
            elif mode == 'std':
                mean, std = param.mean(), param.std()
                norm_fisher[name] = (param - mean) / (std + 1e-8)
            elif mode == 'norm':
                norm = torch.norm(param)
                norm_fisher[name] = param / (norm + 1e-8)

        return norm_fisher

    def save_fisher_matrix(self, filepath="fisher_matrix.pth"):
  
        torch.save(self.fisher_matrix, filepath)
        print(f"Fisher matrix saved to {filepath}")

    def load_fisher_matrix(self,filepath="fisher_matrix.pth"):
        """
        从本地文件加载 Fisher 信息矩阵。
        Args:
            filepath (str): 保存的 Fisher 信息矩阵文件路径
        Returns:
            dict: 加载的 Fisher 信息矩阵
        """
        self.fisher_matrix = torch.load(filepath)
       
        print(f"Fisher matrix loaded from {filepath}")


class SynapticConsolidation:
    def __init__(self, actor, damping=1e-3):
        self.actor = actor
        self.prev_params = {k: v.clone().detach() for k, v in actor.named_parameters()}
        self.prev_reward = 0.0
        self.omega_ki = {k: torch.zeros_like(v) for k, v in actor.named_parameters()}
        self.omega_ki1 = {k: torch.zeros_like(v) for k, v in actor.named_parameters()}
        self.damping = damping
        self.old_params = None
        self.omega={k: torch.zeros_like(v) for k, v in actor.named_parameters()}

    def update(self, current_reward):
        """在每次训练更新后调用"""
        
        for name, param in self.actor.named_parameters():
            if param.requires_grad:
                delta_theta = param.data - self.prev_params[name]
                delta_r = current_reward - self.prev_reward

                self.omega_ki[name] += delta_theta * delta_r
                self.omega_ki1[name] += torch.abs(delta_theta) * abs(delta_r)

                # 更新前一个参数
                self.prev_params[name] = param.data.clone().detach()

        self.prev_reward = current_reward

    def compute_importance_weights(self):
        """计算参数重要性权重 omega_ik"""
        
        for name in self.omega_ki:
            numerator = self.omega_ki[name]
            denominator = self.omega_ki1[name] + self.damping
            self.omega[name] = self.omega[name]+ torch.abs(numerator / denominator)
        
        self.omega_ki = {k: torch.zeros_like(v) for k, v in self.actor.named_parameters()}
        self.omega_ki1 = {k: torch.zeros_like(v) for k, v in self.actor.named_parameters()}
        self.prev_reward=0

        self.omega=self.normalize_omega(self.omega)

    def normalize_omega(self, omega_param,mode='minmax'):

        norm_omega=omega_param

        for name in norm_omega:
            param = norm_omega[name]
            if mode == 'minmax':
                min_val, max_val = param.min(), param.max()
                norm_omega[name] = (param - min_val) / (max_val - min_val + 1e-8)
            elif mode == 'std':
                mean, std = param.mean(), param.std()
                norm_omega[name] = (param - mean) / (std + 1e-8)
            elif mode == 'norm':
                norm = torch.norm(param)
                norm_omega[name] = param / (norm + 1e-8)

        return norm_omega
        

    def compute_consolidation_loss(self, current_actor, stored_actor_params):
        """生成突触固化损失项，用于加入总损失"""
        if stored_actor_params == None:
            return 0
        loss = 0.0
        for name, param in current_actor.named_parameters():
            if param.requires_grad:
                theta_star = stored_actor_params[name]
                loss += (self.omega[name] * (param - theta_star).pow(2)).sum()
        return loss
    
    def save_omega_matrix(self, filepath="fisher_matrix.pth"):
  
        torch.save(self.omega, filepath)
        print(f"Fisher matrix saved to {filepath}")
    


