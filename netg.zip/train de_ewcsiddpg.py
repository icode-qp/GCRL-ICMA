import copy
import numpy as np
import rospy
from std_msgs.msg import Float32
import os
import sys
from environments_paper2 import Env
from d_mem_buffer1 import MemoryManager
from kfagnets6_kgdesiewc import DDPGAgent
import config
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)

from actionlib_msgs.msg  import GoalStatusArray 
from noises import OUNoise

#########这是第3篇最终训练

from colorama import Fore, Style
import wandb
import random  
import torch
import subprocess
import time
import signal
import pandas as pd
from torch import nn
import swanlab
gazebo_process = None
nav_process=None
def init_plotting():
    config_dict = {key: value for key, value in config.__dict__.items() if not key.startswith("__")}

    swanlab.init(
    # 设置项目名
    project="ICMA",
    experiment_name=config.experiment_name,
    # 设置超参数
    config = config_dict,
    )

def run_training(tasks):
    global pub_average_reward, pub_episode_reward
    print('State Dimensions: ' + str(config.STATE_DIMENSION))
    print('Action Dimensions: ' + str(config.ACTION_DIMENSION))
    print('Action Max: ' + str(config.ACTION_V_MAX) + ' m/s and ' + str(config.ACTION_W_MAX) + ' rad/s')
    
    memory_buffer = MemoryManager(device='cuda')
    
    agent = DDPGAgent(config.STATE_DIMENSION, 
                        config.ACTION_DIMENSION, 
                        config.ACTION_V_MAX,
                        config.ACTION_W_MAX, 
                        memory_buffer,
                        path_save=config.MODEL_SAVE_PATH,
                        path_load = config.MODEL_LOAD_PATH)
    

    if config.LOAD_PRETRAINED:
        agent.load_models(config.STEPS_TO_LOAD)
        agent.ewc.load_fisher_matrix('/home/robot/DDPG_AMR_Control/savemodels/stagec_kgdeewcsiddpg_cs1/save_fisher_4/fisher_ma.pth')
        agent.memory_buffer.load(4,'/home/robot/DDPG_AMR_Control/savemodels/stagec_kgdeewcsiddpg_cs1')
        init_weight_v = torch.tensor([config.init_weight_v]).to(agent.device)
        agent.hybridnet.theta1.data.copy_(init_weight_v)
        hard_update(agent.target_hybridnet, agent.hybridnet)
        print("--------------- Loaded Model ------------------")
        
        
    
    noise = OUNoise(config.ACTION_DIMENSION, 
                    max_sigma = 0.1, 
                    min_sigma = 0.1, 
                    decay_period = 100000)
    
    # env = Env(action_dim = config.ACTION_DIMENSION)
    
    steps = 0
    ep1=0
    task_index=config.task_init_index
    for task, task_id,nav_name in tasks:

        # init_weight_v = torch.tensor([config.init_weight_v]).to(agent.device)
        # init_weight_w = torch.tensor([config.init_weight_w]).to(agent.device)

        # agent.hybridnet.theta1=nn.Parameter(init_weight_v)

        task_steps=0
        print(f"---------------------- STARTING TASK {task_id} --------------------")
        
        # Launch Gazebo environment for the task
        launch_environment(task,nav_name)
        env = Env(action_dim = config.ACTION_DIMENSION)
        agent.load_env(env)
        env.respawn_goal.stage=task_id
        rewards_all_episodes = []
        gaol_reach_all_episodes =[]

        

        for ep in range(config.MAX_EPISODES[task_index]):
            print(f"---------------------- EPISODE {ep + 1} --------------------")
            done = False

            state = env.reset()
            
            rewards_current_episode = 0.0
            past_action = np.zeros(config.ACTION_DIMENSION)
            episode_steps = 0
            ep1=ep1+1
            agent.theta_ref=state[92]
            
            while not done:
                steps += 1
                task_steps+=1
                episode_steps += 1
                state = np.float32(state)

                # action = agent.get_action(state)
    
                action = agent.hybrid_action_hynet(state)

                if agent.simlar_cof>0.99:
                
                    N = copy.deepcopy(noise.get_noise(t = task_steps))
                    N[0] = N[0] * config.ACTION_V_MAX / 4.0
                    N[1] = N[1] * config.ACTION_W_MAX
                    if config.ALLOW_REVERSE:
                        action[0] = np.clip(action[0] + N[0], -config.ACTION_V_MAX, config.ACTION_V_MAX)
                    else:
                        action[0] = np.clip(action[0] + N[0], 0.1, config.ACTION_V_MAX)
                    action[1] = np.clip(action[1] + N[1], -config.ACTION_W_MAX, config.ACTION_W_MAX)
                

                next_state, reward, done = env.step(action, past_action)

                # reward=reward+float((1-agent.simlar_cof)*config.r_shape)
                
                if agent.simlar_cof<0.4:
                    reward=reward+config.r_shape
                
                rewards_current_episode += reward
                next_state = np.float32(next_state)

                agent.memory_buffer.current_buffer.add(state, action, reward, next_state, done,agent.ks_action_save)

                agent.memory_buffer.store_step(state, action, reward, next_state, done,agent.ks_action_save)

                state = copy.deepcopy(next_state)
                
                # print("step: {} | reward: {} | done: {} | action: {},{}".format(steps, reward, done, action[0], action[1]))
                
                past_action = copy.deepcopy(action)
                
                if(steps % config.LEARN_RATE == 0 and task_steps > config.MIN_BUFFER_SIZE):
                    for i in range(20):
                        agent.learn()
                        # print(f"{Fore.BLUE}-------------------- Agent Learning ---------------{Style.RESET_ALL}")
                        
                if config.MAX_STEPS[task_index] <= episode_steps:
                    done = True
                
                if(steps % config.TARGET_UPDATE_RATE == 0 and task_steps > config.MIN_BUFFER_SIZE):
                    agent.update_target()
                    # print(f"{Fore.RED}-------------------- Updating Target Networks ---------------{Style.RESET_ALL}")
                    
                if (steps % config.NETWORK_SAVE_RATE == 0 and task_steps > config.MIN_BUFFER_SIZE):
                    agent.save_models(steps)
                    print(f"{Fore.GREEN}-------------------- SAVING THE MODEL ---------------{Style.RESET_ALL}")
                    print("save_model_steps,tasks",steps,task_id)
                    

            agent.memory_buffer.end_episode(env.reach_score,np.array([env.goal_x,env.goal_y]))

            rewards_all_episodes.append(rewards_current_episode)
            gaol_reach_all_episodes.append(env.reach_score)
                    
            if ep<100:

                avg_reward = np.sum(rewards_all_episodes[max(0, ep - 100):(ep + 1)])/100
                avg_reach_rate = np.sum(gaol_reach_all_episodes[max(0, ep - 100):(ep + 1)])/100
            else:
                avg_reward = np.mean(rewards_all_episodes[max(0, ep - 100):(ep + 1)])
                avg_reach_rate = np.mean(gaol_reach_all_episodes[max(0, ep - 100):(ep + 1)])
            
            swanlab.log({"episodes": ep1,
                    "episode_reward": rewards_current_episode,
                    "average_reward": avg_reward,
                    "avg_reach_rate": avg_reach_rate,
                    'theta1':agent.hybridnet.theta1.data})
            
            swanlab.log({'steps': steps,"collution_num":env.collision_num,
                        "goal_rech_num":env.goal_reach_num}) 
             
            
            print("------------------------------------- EPISODE END -----------------------------------------".format(ep + 1))
        
        agent.ewc.consolidate()

        agent.si.compute_importance_weights()
        
        if not os.path.isdir(f"{agent.path_save}/save_fisher_{task_id}"):
            os.makedirs(f"{agent.path_save}/save_fisher_{task_id}")
        excel_path = f"{agent.path_save}/save_fisher_{task_id}/fisher_ma.pth"

        if not os.path.isdir(f"{agent.path_save}/save_omega_{task_id}"):
            os.makedirs(f"{agent.path_save}/save_omega_{task_id}")
        excel_path_omega = f"{agent.path_save}/save_omega_{task_id}/omega.pth"

        agent.ewc.save_fisher_matrix(excel_path)
        agent.si.save_omega_matrix(excel_path_omega)

        task_index=task_index+1

        # agent.knowledge_extraction()


        agent.memory_buffer.save(task_id,agent.path_save)
        agent.memory_buffer.consolidate_by_goal_position_dbscan(nav_name)

        
        init_weight_v = torch.tensor([config.init_weight_v]).to(agent.device)
        agent.hybridnet.theta1.data.copy_(init_weight_v)

    print('Completed Training')
    print("saving...")
    agent.save_models(steps)
    print("saved")


def launch_environment(env_name,nav_launch_name):
    global gazebo_process ,nav_process
    try:
        # 清理上一个环境
        terminate_gazebo()

        print(f"Launching environment: {env_name}")
        
        # 确保环境变量正确传递
        env = os.environ.copy()
        env['DISPLAY'] = os.getenv('DISPLAY', ':0')
        
        # 启动新的 Gazebo 环境
        gazebo_process = subprocess.Popen(
            ['roslaunch', 'turtlebot3_gazebo', f'{env_name}.launch'],
            env=env,
            preexec_fn=os.setsid,
            stdout=None,
            stderr=None
        )
        

              
        # nav_process = subprocess.Popen(
        #     ['roslaunch', 'turtlebot3_navigation', f'{nav_launch_name}.launch'],
        #     preexec_fn=os.setsid,
        #     # stdout=subprocess.DEVNULL,
        #     # stderr=subprocess.DEVNULL
        # )
        
        
        return gazebo_process, nav_process  # 返回两个进程句柄

    except subprocess.CalledProcessError as e:
        print(f"Process execution failed: {e}")
        terminate_gazebo()  # 确保清理已启动的进程
        if 'nav_process' in locals():
            os.killpg(os.getpgid(nav_process.pid), signal.SIGTERM)
        raise
    except Exception as e:
        print(f"Error launching environment {env_name}: {e}")
        raise


def terminate_gazebo():
    """
    确保完全终止所有 Gazebo 相关进程
    """
    try:
        print("Killing remaining Gazebo processes (if any)...")
        os.system("pkill -9 gzserver")
        os.system("pkill -9 gzclient")
        os.system("pkill -9 roslaunch")
        # 等待进程完全关闭
        if not wait_for_process_termination(["gzserver", "gzclient", "roslaunch"], timeout=10):
            print("Warning: Some processes are still running.")
    except Exception as e:
        print(f"Error while terminating Gazebo: {e}")

def terminate_nav():
    global nav_process
    if nav_process and nav_process.poll() is None:
        os.killpg(os.getpgid(nav_process.pid), signal.SIGTERM)
        nav_process.wait()  # 等待进程真正结束
        print("Navigation process terminated.")
        _wait_for_termination(nav_process, timeout=5)

def nav_start(nav_launch_name):
    global nav_process
    nav_process = subprocess.Popen(
        ['roslaunch', 'turtlebot3_navigation', f'{nav_launch_name}.launch'],
        preexec_fn=os.setsid,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    if wait_for_topic("/move_base/status", GoalStatusArray, timeout=15):
        rospy.loginfo(" 导航核心服务已就绪")
    else:
        rospy.logwarn(" 部分功能未初始化，继续执行可能存在风险")
    

def wait_for_process_termination(process_names, timeout=10):
    """
    等待指定的进程全部终止
    :param process_names: 要检查的进程名称列表（如 ['gzserver', 'gzclient', 'roslaunch']）
    :param timeout: 最大等待时间（秒）
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        still_running = False
        for process_name in process_names:
            result = subprocess.run(
                ["pgrep", "-f", process_name],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            if result.returncode == 0:  # 进程仍在运行
                still_running = True
                break
        if not still_running:
            print(f"All processes ({process_names}) terminated.")
            return True
        time.sleep(0.1)  # 每 0.5 秒检查一次
    print(f"Timeout waiting for processes ({process_names}) to terminate.")
    return False

def wait_for_topic(topic_name, topic_type, timeout=30):
    try:
        rospy.wait_for_message(topic_name,  topic_type, timeout)
        return True 
    except rospy.ROSException:
        return False
    
def _wait_for_termination(proc, timeout=5):
    """等待进程终止，支持超时和状态轮询"""
    start_time = time.time() 
    while time.time()  - start_time < timeout:
        if proc.poll()  is not None:  # 进程已终止 
            print("导航进程已确认终止")
            return 
        time.sleep(0.1) 
    print(f"超时：进程未在 {timeout} 秒内终止，尝试强制终止")
    os.killpg(os.getpgid(proc.pid),  signal.SIGKILL)

def fixed_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 如果你使用GPU
    torch.cuda.manual_seed_all(seed)  # 如果你有多个GPU
    torch.backends.cudnn.deterministic = True  # 设置为True以确保结果可重复
    torch.backends.cudnn.benchmark = False  # 设置为False以提高结果可重复性
    np.random.seed(seed)
    random.seed(seed)

def hard_update(target, source):
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(param.data)

if __name__ == '__main__':
    rospy.init_node('ddpg_train')
    fixed_seed(config.randseed)
    init_plotting()
    tasks = config.task
    run_training(tasks)