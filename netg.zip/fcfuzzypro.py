import torch
import torch.nn as nn
import numpy as np
import config
import torch.nn.functional as F
from torch.distributions import Normal
import itertools
import math
def fanin_init(size, fanin=None):
    fanin = fanin or size[0]
    v = 1. / np.sqrt(fanin)
    return torch.Tensor(size).uniform_(-v, v)

class TriangularMF(nn.Module):
    def __init__(self, num_mfs, input_dim):
        super().__init__()
        self.num_mfs = num_mfs
        self.input_dim = input_dim
        self.mf_centers = torch.linspace(0, 1, num_mfs)
        self.mf_band = 1.0 / (num_mfs - 1)
        self.centers = self.mf_centers.repeat(input_dim, 1)
        self.band = self.mf_band

    def forward(self, x):
        x = x.unsqueeze(-1)  # (batch, input_dim, 1)
        centers = self.centers.to(x.device)
        band = self.band
        left = centers - band
        right = centers + band

        μ = torch.maximum(
            torch.zeros_like(x),
            torch.minimum((x - left) / (centers - left), (right - x) / (right - centers))
        )
        μ = torch.nan_to_num(μ, nan=0.0)
        return μ  # (batch, input_dim, num_mfs)

class FuzzyRuleLayer(nn.Module):
    def __init__(self, input_dim, num_mfs, output_dim):
        super().__init__()
        self.input_dim = input_dim
        self.num_mfs = num_mfs
        self.output_dim = output_dim

        self.mf = TriangularMF(num_mfs, input_dim)
        mf_indices = list(itertools.product(range(num_mfs), repeat=input_dim))
        self.register_buffer("rules", torch.tensor(mf_indices))  # (num_rules, input_dim)
        self.num_rules = len(mf_indices)

        self.rule_outputs = nn.Parameter(torch.ones(self.num_rules, output_dim) * 0.01)

    def forward(self, x):
        μ = self.mf(x)  # (batch, input_dim, num_mfs)
        rule_μs = [μ[:, i, self.rules[:, i]] for i in range(self.input_dim)]
        rule_activations = torch.stack(rule_μs, dim=-1).prod(dim=-1)  # (batch, num_rules)

        output = rule_activations @ self.rule_outputs  # (batch, output_dim)
        norm = rule_activations.sum(dim=-1, keepdim=True) + 1e-6
        return output / norm

class FuzzyLayerGroup(nn.Module):
    def __init__(self, layer_config, num_mfs):
        """
        layer_config: list of tuples [(in_dim, out_dim), ...]
        """
        super().__init__()
        self.subsystems = nn.ModuleList([
            FuzzyRuleLayer(in_dim, num_mfs, out_dim)
            for in_dim, out_dim in layer_config
        ])

    def forward(self, x):
        sub_outputs = []
        idx = 0
        for sub in self.subsystems:
            in_dim = sub.input_dim
            xi = x[:, idx:idx + in_dim]
            idx += in_dim
            yi=sub(xi)
            # yi = torch.sigmoid(sub(xi))  # You can replace with other activation if needed
            sub_outputs.append(yi)
        return torch.cat(sub_outputs, dim=-1)


class MyHierarchicalFuzzy(nn.Module):
    def __init__(self, num_mfs=3):
        super().__init__()
        self.layer1 = FuzzyLayerGroup([(3, 1)] * 21 + [(1, 1)], num_mfs)
        self.layer2 = FuzzyLayerGroup([(4, 1)] * 5+[(2,1)], num_mfs)
        self.layer3 = FuzzyLayerGroup([(6, 2)], num_mfs)

        # 初始化权重
        self._init_weights()

    def _init_weights(self):
        for layer in [self.layer1, self.layer2, self.layer3]:
            for sub in layer.subsystems:
                nn.init.constant_(sub.rule_outputs, 0.1)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        return x

class HierarchicalFuzzySystem(nn.Module):
    def __init__(self, input_dim, num_mfs, layer_configs):
        """
        layer_configs: List of lists, each sublist defines a layer.
                       Each element in the sublist is a tuple: (input_dim, output_dim)
                       Example:
                         [
                            [(4, 1)] * 23 + [(2, 1)],  # 第一层：23个4维子系统 + 1个2维子系统
                            [(4, 1)] * 4,             # 第二层：4个子系统，每个4维->1维
                            [(4, 2)]                  # 第三层：1个子系统，4维->2维
                         ]
        """
        super().__init__()
        self.layers = nn.ModuleList()
        for layer_config in layer_configs:
            subsystems = nn.ModuleList()
            for in_dim, out_dim in layer_config:
                subsystems.append(FuzzyRuleLayer(in_dim, num_mfs, out_dim))
            self.layers.append(subsystems)

    def forward(self, x):
        for subsystems in self.layers:
            sub_outputs = []
            idx = 0
            for sub in subsystems:
                in_dim = sub.input_dim
                xi = x[:, idx:idx + in_dim]
                idx += in_dim
                # yi = sub(xi)
                yi = torch.sigmoid(sub(xi))
                sub_outputs.append(yi)
            x = torch.cat(sub_outputs, dim=-1)
        return x


class Critic(nn.Module):

    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()

        num_mfs=4
        self.layer1 = FuzzyLayerGroup([(4, 1)] * 24, num_mfs)
        self.layer2 = FuzzyLayerGroup([(4, 1)] * 6, num_mfs)
        self.layer3 = FuzzyLayerGroup([(3, 1)] * 2, num_mfs)
        self.layer4 = FuzzyLayerGroup([(2, 1)] * 1, num_mfs)

        self._init_weights()

    def _init_weights(self):
        for layer in [self.layer1, self.layer2, self.layer3,self.layer4]:
            for sub in layer.subsystems:
                nn.init.constant_(sub.rule_outputs, 0.01)


    def forward(self, state, action):

        x = torch.cat((state, action), dim=1)
        x=self.normalize_for_fuzzy(x)

        x=torch.clamp(torch.relu(self.layer1(x)),  max=1) 
        x=torch.clamp(torch.relu(self.layer2(x)),  max=1) 
        x=torch.clamp(torch.relu(self.layer3(x)),  max=1) 
        vs=torch.clamp(torch.relu(self.layer4(x)),  max=1) 

        # x = torch.relu(self.layer1(x))
        # x = torch.relu(self.layer2(x))
        # x = torch.relu(self.layer3(x))
        # vs = torch.relu(self.layer4(x))

        return vs
    
    def normalize_for_fuzzy(self,tensor):
        
        # 维度分解 
        point_cloud = tensor[:, :90]    # 前90维：点云数据（原范围0-3.5）
        action = tensor[:, 90:92]       # 第91-92维：动作历史（原范围0-0.5和-1-1）
        angle = tensor[:, 92]           # 第93维：角度（原范围-π到π）
        dis = tensor[:, 93]
        action_current= tensor[:, 94:96]       # 第94维：速度（原范围0-5）
    

        pc_norm = point_cloud / 3.5 
        
        act1_norm = action[:, 0] / 0.5 
        act2_norm = (action[:, 1] + 1) / 2  # 核心修改：x'=(x+1)/2 

        act1_norm1 = action_current[:, 0] / 0.5 
        act2_norm1 = (action_current[:, 1] + 1) / 2  # 核心修改：x'=(x+1)/2 
        
 
        angle_norm = (angle + math.pi)  / (2 * math.pi)   # [-π,π] => [0,1]
        
        dis_norm = dis / 5 
    
        # 重建张量 
        return torch.cat([ 
            pc_norm,
            act1_norm.unsqueeze(-1), 
            act2_norm.unsqueeze(-1), 
            angle_norm.unsqueeze(-1), 
            dis_norm.unsqueeze(-1) ,
            act1_norm1.unsqueeze(-1),
            act2_norm1.unsqueeze(-1), 
        ], dim=1)
        


class Fuzzy_Actor(nn.Module):
    """
    # ---Actor---
    """

    def __init__(self, state_dim, action_dim, action_v_max, action_w_max):
        super(Fuzzy_Actor, self).__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.action_v_max = action_v_max
        self.action_w_max = action_w_max

        num_mfs=4

        ################3层
        # self.layer1 = FuzzyLayerGroup([(4, 1)]*23+[(2,1)], num_mfs)
        # self.layer2 = FuzzyLayerGroup([(4, 1)]*6, num_mfs)
        # self.layer3 = FuzzyLayerGroup([(6, action_dim)], num_mfs)

        ################
        self.layer1 = FuzzyLayerGroup([(10, 1)]*9+[(4,1)], 2)
        self.layer2 = FuzzyLayerGroup([(2, 1)]*5, 10)
        self.layer3 = FuzzyLayerGroup([(5, action_dim)], 6)
        ###############
        # self.layer1 = FuzzyLayerGroup([(10, 1)]*9, 2)
        # self.layer2 = FuzzyLayerGroup([(4, 1)]*2+[(1,1)], 4)
        # self.layer3 = FuzzyLayerGroup([(3, 1)], 6)
        # self.layer4 = FuzzyLayerGroup([(5, action_dim)], 6)

        ###############6层
        # self.layer1 = FuzzyLayerGroup([(2, 1)]*47, num_mfs)
        # self.layer2 = FuzzyLayerGroup([(2, 1)]*22+[(3,1)], num_mfs)
        # self.layer3 = FuzzyLayerGroup([(2, 1)]*10+[(3,1)], num_mfs)
        # self.layer4 = FuzzyLayerGroup([(2, 1)]*4+[(3,1)], num_mfs)
        # self.layer5 = FuzzyLayerGroup([(2, 1)]+[(3,1)], num_mfs)
        # self.layer6 = FuzzyLayerGroup([(2, action_dim)], num_mfs)
        
        self._init_weights()

    def _init_weights(self):
        for layer in [self.layer1, self.layer2, self.layer3]:
        # for layer in [self.layer1, self.layer2, self.layer3,self.layer4,self.layer5,self.layer6]:
            for sub in layer.subsystems:
                nn.init.constant_(sub.rule_outputs, 0.1)



    def forward(self, state):
        x=self.normalize_for_fuzzy(state)
        # x1=self.normalize_for_fuzzy(state)
        ################3层
        x=torch.clamp(torch.relu(self.layer1(x)),  max=1) 
        x=torch.clamp(torch.relu(self.layer2(x)),  max=1)
        action = self.layer3(x)

        ###################6层

        # x=torch.clamp(torch.relu(self.layer1(x[:, :90])),  max=1) 
        # x=torch.clamp(torch.relu(self.layer2(x)),  max=1)
        # x=torch.clamp(torch.relu(self.layer3(x)),  max=1)

        # torch.cat([x,x1[:,90:94]],dim=1)
        # action = self.layer4(x)

        ###################6层
        # x=torch.clamp(torch.relu(self.layer1(x)),  max=1) 
        # x=torch.clamp(torch.relu(self.layer2(x)),  max=1)
        # x=torch.clamp(torch.relu(self.layer3(x)),  max=1)
        # x=torch.clamp(torch.relu(self.layer4(x)),  max=1)
        # x=torch.clamp(torch.relu(self.layer5(x)),  max=1)
        # action = self.layer6(x)

        if len(action.shape)<2:
            action[0] = torch.sigmoid(action[0]) * self.action_v_max
            action[1] = torch.tanh(action[1]) * self.action_w_max
        else:
            action[:, 0] = torch.sigmoid(action[:, 0]) * self.action_v_max
            action[:, 1] = torch.tanh(action[:, 1]) * self.action_w_max
        return action

        # if len(action.shape)<2 :
        #     action = action.clone()
        #     action[0]=(action[0]+1)/2*self.action_v_max
        #     action[1]=action[1]*self.action_w_max
        # else:
        #     action = action.clone()
        #     action[:,0]=(action[:,0]+1)/2.0*self.action_v_max
        #     action[:,1]=action[:,1]*self.action_v_max


    
    def normalize_for_fuzzy(self,tensor):
        
        # 维度分解 
        point_cloud = tensor[:, :90]    # 前90维：点云数据（原范围0-3.5）
        action = tensor[:, 90:92]       # 第91-92维：动作历史（原范围0-0.5和-1-1）
        angle = tensor[:, 92]           # 第93维：角度（原范围-π到π）
        dis = tensor[:, 93]        # 第94维：速度（原范围0-5）
    

        pc_norm = point_cloud / 3.5 
        
        act1_norm = action[:, 0] / 0.5 
        act2_norm = (action[:, 1] + 1) / 2  # 核心修改：x'=(x+1)/2 
        
        angle_norm = (angle + math.pi)  / (2 * math.pi)   # [-π,π] => [0,1]
        
        dis_norm = dis / 5 
    
        # 重建张量 
        return torch.cat([ 
            pc_norm,
            act1_norm.unsqueeze(-1), 
            act2_norm.unsqueeze(-1), 
            angle_norm.unsqueeze(-1), 
            dis_norm.unsqueeze(-1) 
        ], dim=1)
        
