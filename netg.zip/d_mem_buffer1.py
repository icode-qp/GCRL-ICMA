import torch
import numpy as np
import random
from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN
import pickle
import os
from collections import deque
from itertools import chain, islice
import config
def fixed_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 如果你使用GPU
    torch.cuda.manual_seed_all(seed)  # 如果你有多个GPU
    torch.backends.cudnn.deterministic = True  # 设置为True以确保结果可重复
    torch.backends.cudnn.benchmark = False  # 设置为False以提高结果可重复性
    np.random.seed(seed)
    random.seed(seed)

class PERTrajectoryBuffer:
    def __init__(self, max_size=10000, alpha=0.6, epsilon=1e-6):
        self.trajectories = []
        self.goal=[]
        self.max_size = max_size
        self.alpha = alpha
        self.epsilon = epsilon
        fixed_seed(config.randseed)

    def add(self, trajectory,goal):
       
        if len(self.trajectories) >= self.max_size:
            self.trajectories.pop(0)
            self.priorities.pop(0)
        self.trajectories.append(trajectory)
        self.goal.append(goal)

    def sample(self, count):
        total = sum(self.priorities)
        probs = [p / total for p in self.priorities]
        indices = np.random.choice(len(self.trajectories), count, p=probs)
        sampled = [self.trajectories[i] for i in indices]

        flat = [item for traj in sampled for item in traj]
        s_array = np.float32([t[0] for t in flat])
        a_array = np.float32([t[1] for t in flat])
        r_array = np.float32([t[2] for t in flat])
        s_next_array = np.float32([t[3] for t in flat])
        d_array = np.float32([t[4] for t in flat])
        ks_a_sample = np.float32([t[5] for t in flat])

        # goal_array = np.float32([t[6] for t in flat])
        return s_array, a_array, r_array, s_next_array, d_array, ks_a_sample
    
    def revise_sample(self, count, beta=0.4):
        total = sum(self.priorities)
        probs = [p / total for p in self.priorities]
        indices = np.random.choice(len(self.trajectories), count, p=probs)
        sampled = [self.trajectories[i] for i in indices]

        # Importance sampling weights
        N = len(self.trajectories)
        weights = [(N * probs[i]) ** (-beta) for i in indices]
        max_w = max(weights)
        weights = [w / max_w for w in weights]  # normalize

        flat = [item for traj in sampled for item in traj]
        s_array = np.float32([t[0] for t in flat])
        a_array = np.float32([t[1] for t in flat])
        r_array = np.float32([t[2] for t in flat])
        s_next_array = np.float32([t[3] for t in flat])
        d_array = np.float32([t[4] for t in flat])
        ks_a_sample = np.float32([t[5] for t in flat])

        return s_array, a_array, r_array, s_next_array, d_array, ks_a_sample, weights

    def get_all(self):
        return self.trajectories.copy(),self.goal.copy()

    def clear(self):
        self.trajectories.clear()
        self.goal.clear()

class PERBuffer:
    def __init__(self, size, alpha=0.6, epsilon=1e-5):
        self.buffer = deque(maxlen=size)
        self.priorities = deque(maxlen=size)
        self.maxSize = size
        self.alpha = alpha
        self.epsilon = epsilon
        fixed_seed(config.randseed)
    def add(self, s, a, r, new_s, done, ks_a):
        transition = (s, a, r, new_s, done, ks_a)
        self.buffer.append(transition)
        # 初始优先级设置为最大值，确保新数据可以被采样
        max_prio = max(self.priorities) if self.priorities else 1.0
        self.priorities.append(max_prio)

    def sample(self, count, beta=0.4):
        if len(self.buffer) == 0:
            raise ValueError("The buffer is empty")

        prios = np.array(self.priorities, dtype=np.float32)
        probs = prios ** self.alpha
        probs /= probs.sum()

        indices = np.random.choice(len(self.buffer), count, p=probs)
        samples = [self.buffer[idx] for idx in indices]

        # IS权重
        total = len(self.buffer)
        weights = (total * probs[indices]) ** (-beta)
        weights /= weights.max()  # normalize

        s_array = np.float32([sample[0] for sample in samples])
        a_array = np.float32([sample[1] for sample in samples])
        r_array = np.float32([sample[2] for sample in samples])
        new_s_array = np.float32([sample[3] for sample in samples])
        done_array = np.float32([sample[4] for sample in samples])
        ks_a_array = np.float32([sample[5] for sample in samples])

        return s_array, a_array, r_array, new_s_array, done_array, ks_a_array, indices, weights

    def update_priorities(self, indices, td_errors):
        for idx, td in zip(indices, td_errors):
            priority = (abs(td) + self.epsilon)
            self.priorities[idx] = priority

    def save(self, task_name, save_dir="buffers"):
        os.makedirs(f"{save_dir}/save_buffer_{task_name}", exist_ok=True)
        path = os.path.join(save_dir, f"{task_name}_buffer.pkl")
        with open(path, 'wb') as f:
            pickle.dump((self.buffer, self.priorities), f)
        print(f"[✔] Buffer saved to {path}")

    def load(self, task_name, save_dir="buffers"):
        path = os.path.join(save_dir, f"{task_name}_buffer.pkl")
        with open(path, 'rb') as f:
            self.buffer, self.priorities = pickle.load(f)
        print(f"[✔] Buffer loaded from {path}")

    def __len__(self):
        return len(self.buffer)

class MemoryManager:
    def __init__(self, device="cuda", max_size=100000, old_size=200):
        self.success_buffer = PERTrajectoryBuffer(1000)
        self.current_buffer = PERBuffer(max_size)

        self.old_task_buffers = {}
        self.episode_buffer = []
        self.device = device
        
        self.old_size = old_size
        fixed_seed(config.randseed)

    def store_step(self, s, a, r, s_, done, ks_a_sample):
        self.episode_buffer.append((s, a, r, s_, done, ks_a_sample))  #当前回合每一个元组的列表


    def end_episode(self, success: bool, cur_goal,bonus=1.0):
        if not self.episode_buffer:
            return
        if success:
            self.success_buffer.add(self.episode_buffer.copy(),cur_goal)  #当前回合轨迹列表
        self.episode_buffer.clear()

    def sample(self, batch_size):

        return self.current_buffer.sample(batch_size)
    
    # def sample_old(self, batch_size):

    #     num_old = batch_size
    #     old_samples = []
        
    #     old_samples = ([], [], [], [], [], [],[])
    #     if self.old_task_buffers and num_old > 0:
    #         buffer_count = len(self.old_task_buffers)
    #         base, remainder = divmod(num_old, buffer_count)
    #         combined = [None] * num_old
    #         idx = 0 
    #         for i, buffer in enumerate(self.old_task_buffers.values()): 
    #             quota = base + (i == buffer_count - 1) * remainder 
    #             sampled = buffer if len(buffer) <= quota else random.sample(buffer,  quota)
    #             combined[idx:idx+len(sampled)] = sampled 
    #             idx += len(sampled)

    #         old_samples = list(zip(*combined[:idx]))
        
    #     s_array = np.float32(list(old_samples[0]))
    #     a_array = np.float32(list(old_samples[1]))
    #     # r_array = np.float32(list(old_samples[2]))
    #     # new_s_array = np.float32(list(old_samples[3]))
    #     # done_array = np.float32(list(old_samples[4]))
    #     # ks_a_array = np.float32(list(old_samples[5]))


    #     return s_array, a_array


    def sample_old(self, batch_size):
        if not self.old_task_buffers or batch_size <= 0:
            return None, None

        task_names = list(self.old_task_buffers.keys())
        task_count = len(task_names)
        base, remainder = divmod(batch_size, task_count)

        selected_steps = []

        for i, task_name in enumerate(task_names):
            trajs = self.old_task_buffers[task_name]

            # 扁平化所有 step
            steps = list(chain.from_iterable(trajs))

            # 分配配额
            quota = base + (i == task_count - 1) * remainder

            # 采样
            if len(steps) <= quota:
                sampled = steps
            else:
                sampled = random.sample(steps, quota)

            selected_steps.extend(sampled)

        if not selected_steps:
            return None, None

        # 使用 NumPy 向量化转换
        selected_steps = list(islice(selected_steps, batch_size))  # 限制最终步数
        s_array = np.array([step[0] for step in selected_steps], dtype=np.float32)
        a_array = np.array([step[1] for step in selected_steps], dtype=np.float32)

        return s_array, a_array

    def consolidate_by_goal_position_dbscan(self, task_id):

        all_trajs,all_goal = self.success_buffer.get_all()

        if len(all_trajs) == 0:
            return
        
        feats = np.array(all_goal)

        db = DBSCAN(eps=0.2, min_samples=1)

        labels = db.fit_predict(feats)

        unique_labels = set(labels)
        selected_indices = []

        for lbl in unique_labels:
            if lbl == -1:
                continue  # 忽略噪声点

        # 找出属于当前聚类标签的索引
            idxs = np.where(labels == lbl)[0]

            best_idx = max(idxs, key=lambda idx: sum([step[2] for step in all_trajs[idx]]))
            selected_indices.append(best_idx)

        selected = [all_trajs[i] for i in selected_indices]

        self.old_task_buffers[task_id] = selected
        self.success_buffer.clear()




    def save(self, task_name, save_dir="buffers"):
        os.makedirs(f"{save_dir}/save_buffer_{task_name}", exist_ok=True)

        path=f"{save_dir}/save_buffer_{task_name}_buffer.pkl"

        with open(path, 'wb') as f:
            pickle.dump((self.current_buffer,self.old_task_buffers), f)
        print(f"[✔] Buffer saved to {path}")


    def load(self, task_name, save_dir="buffers"):
        path = f"{save_dir}/save_buffer_{task_name}_buffer.pkl"
        with open(path, 'rb') as f:
            self.current_buffer,self.old_task_buffers= pickle.load(f)
        print(f"[✔] Buffer loaded from {path}")

#####用法
# memory = MemoryManager(agent, device='cuda')

# # during env loop
# memory.store_step(state, action, reward, next_state, done, action)

# # at end of episode
# memory.end_episode(success=done and info["arrived"])

# # sample training batch
# s, a, r, s_, d, ks_a = memory.sample(batch_size=64)
# agent.train_step(s, a, r, s_, d)

# # after task ends
# memory.consolidate_task("task_nav_v1")
